package modelo;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Clase manejadora para la clase Categorias
 */
public class CategoriasUtils {
    private ArrayList<Categorias> catList;

    public CategoriasUtils() {
    }

    public CategoriasUtils(HashMap<String, ExcelUtils.WrapperCategoria> mapCategorias) {
        this.catList = crearListaCategorias(mapCategorias);
    }

    public ArrayList<Categorias> getCatList() {
        return catList;
    }

    private ArrayList<Categorias> crearListaCategorias(HashMap<String, ExcelUtils.WrapperCategoria> mapCategorias) {
        ArrayList<Categorias> ret = new ArrayList<>();
        int i = 1;

        for (String elem: mapCategorias.keySet()){

            Categorias c = new Categorias();
            c.setIdCategoria(i);
            c.setNombreCategoria(elem);
            c.setSalarioBaseCategoria(mapCategorias.get(elem).getBase());
            c.setComplementoCategoria(mapCategorias.get(elem).getComplementos());
            ret.add(c);
            i++;
        }

        return ret;
    }

    public Integer asociarConIdCategoria(String nombreCategoria) {
        for (Categorias c : catList) {
            if (c.getNombreCategoria().equals(nombreCategoria)){
                return c.getIdCategoria();
            }
        }

        return -1;
    }

    public String getNombreCategoria(Integer idCategoria) {
        for (Categorias c : catList) {
            if (c.getIdCategoria() == idCategoria){
                return c.getNombreCategoria();
            }
        }
        return null;
    }

    public double getBaseCategoria(Integer idCategoria) {
        for (Categorias c : catList) {
            if (c.getIdCategoria() == idCategoria){
                return c.getSalarioBaseCategoria();
            }
        }
        return -1;
    }

    public double getComplementoCategoria(Integer idCategoria) {
        for (Categorias c : catList) {
            if (c.getIdCategoria() == idCategoria){
                return c.getComplementoCategoria();
            }
        }
        return -1;
    }
}
