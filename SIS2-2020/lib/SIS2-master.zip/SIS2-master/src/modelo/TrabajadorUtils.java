package modelo;

import java.util.ArrayList;

/**
 * Manejador de Trabajadorbbdd
 */
public class TrabajadorUtils {

    private ArrayList<String> paises;
    private ArrayList<Trabajadorbbdd> trabList;
    private ArrayList<String> prorrateoSoN;
    private ArrayList<Empresas> empresas;
    private EmpresasUtils eUtils;

    /**
     * Constructor del manejador de Trabajadorbbdd
     * @param trabajadores
     * @param prorrateoSoN
     * @param empresasUtils
     * @param paises
     */
    public TrabajadorUtils(ArrayList<Trabajadorbbdd> trabajadores, ArrayList<String> prorrateoSoN, EmpresasUtils empresasUtils, ArrayList<String> paises) {
        this.trabList = trabajadores;
        this.prorrateoSoN = prorrateoSoN;
        this.empresas = empresasUtils.getEmpresasListUtils();   // Lista de empresas
        this.eUtils = empresasUtils;    // Clase manejadora de empresas
        this.paises = paises;
    }

    /**
     * Getter de lista de Trabajadorbbdd
     * @return  lista de trabajadores
     */
    public ArrayList<Trabajadorbbdd> getTrabList() {
        return trabList;
    }

    /**
     * Setter de lista de trabajadores
     * @param trabList
     */
    public void setTrabList(ArrayList<Trabajadorbbdd> trabList) {
        this.trabList = trabList;
    }

    /**
     * Obtenemos lista con SI o NO dependiendo de si tiene prorrateo cada trabajador
     * @return
     */
    public ArrayList<String> getProrrateoSoN() {
        return prorrateoSoN;
    }

    /**
     * Set prorrateo lista SI o NO
     * @param prorrateoSoN
     */
    public void setProrrateoSoN(ArrayList<String> prorrateoSoN) {
        this.prorrateoSoN = prorrateoSoN;
    }

    public ArrayList<Empresas> getEmpresas() {
        return empresas;
    }

    public void setEmpresas(ArrayList<Empresas> empresas) {
        this.empresas = empresas;
    }

    /**
     * Obtenemos manejador empresas
     * @return
     */
    public EmpresasUtils geteUtils() {
        return eUtils;
    }

    public void seteUtils(EmpresasUtils eUtils) {
        this.eUtils = eUtils;
    }

    public ArrayList<String> getPaises() {
        return paises;
    }
}
