package modelo;

import java.util.Iterator;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

/**
 * Clase para acceso a tabla de bbdd de Empresas
 */
public class BBDDEmpresa {

    /**
     * Inserta una nueva empresa a la bbdd
     * @param nombreEmpresa
     * @param CIF
     */
    public void addEmpresa(String nombreEmpresa, String CIF){

        Session session = HibernateUtil.getSession();
        Transaction tx = null;
        Integer empresaID = null;
        Empresas empresa = null;

        try{
            tx = session.beginTransaction();
            empresa = new Empresas();
            empresa.setCif(CIF);
            empresa.setNombre(nombreEmpresa);
            empresaID = (Integer) session.save(empresa);
            tx.commit();

        }catch(HibernateException e ){
            if (tx!=null) tx.rollback();
            e.printStackTrace();

        }finally {
            session.close();
        }
    }

    /**
     * Lista las empresas de la bbdd
     * @return
     */
    private List listaEmpresa(){

       return HibernateUtil.getSession().createCriteria(Empresas.class).list();
    }

    /**
     * Comprueba la existencia de la Empresa con un CIF en bbdd
     * @param CIF
     * @return
     */
    public boolean existeEnBBDDEmpresa(String CIF){

        Session session = HibernateUtil.getSession();
        Transaction tx = null;
        List empresasList = null;
        boolean flag = false;

        try{
            tx = session.beginTransaction();
            empresasList = listaEmpresa();

            for(Iterator iterator = empresasList.iterator(); iterator.hasNext();){

                Empresas empresa = (Empresas) iterator.next();

                if(empresa.getCif().equalsIgnoreCase(CIF)){
                    flag = true;
                    break;
                }else{
                    flag = false;
                }

            }
            tx.commit();

        }catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }finally{
            session.close();
        }

        return flag;
    }

    /**
     * Actualiza una empresa existente en la bbdd
     *
     * @param empresaID
     * @param nombreEmpresa
     * @param CIF
     * @return
     */
    public Empresas updateEmpresa(Integer empresaID, String nombreEmpresa, String CIF){

        Session session = HibernateUtil.getSession();
        Transaction tx = null;
        Empresas empresa = null;
        try{
            tx = session.beginTransaction();

            empresa = (Empresas)session.get(Empresas.class, empresaID);

            empresa.setNombre(nombreEmpresa);
            empresa.setCif(CIF);

            session.update(empresa);

            tx.commit();
        }catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }finally{
            session.close();
        }

        return empresa;
    }

}
