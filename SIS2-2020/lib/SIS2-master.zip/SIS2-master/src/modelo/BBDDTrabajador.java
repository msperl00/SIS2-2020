package modelo;


import java.sql.Date;
import java.util.Iterator;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

/**
 * Clase para el manejo de la tabla Trabajdorbbdd
 */
public class BBDDTrabajador {

    List<Trabajadorbbdd> trabs;

    /**
     * Inserta un nuevo trabajador en la bbdd
     * @param idCategorias
     * @param idEmpresas
     * @param nombre
     * @param apellido1
     * @param apellido2
     * @param nifnie
     * @param email
     * @param fechaAlta
     * @param codigoCuenta
     * @param iban
     * @return
     */
    public Trabajadorbbdd addTrabajador(int idCategorias, int idEmpresas, String nombre, String apellido1, String apellido2, String nifnie, String email, Date fechaAlta, String codigoCuenta, String iban){


        Session session = HibernateUtil.getSession();
        Transaction tx = null;
        Integer trabajadorID = null;
        Trabajadorbbdd trabajador = null;

        try{

            tx = session.beginTransaction();
            trabajador = new Trabajadorbbdd();
            trabajador.setNombre(nombre);
            trabajador.setApellido1(apellido1);
            trabajador.setApellido2(apellido2);
            trabajador.setIban(iban);
            trabajador.setCodigoCuenta(codigoCuenta);
            trabajador.setEmail(email);
            trabajador.setIdEmpresa(idEmpresas);
            trabajador.setFechaAlta(fechaAlta);
            trabajador.setNifnie(nifnie);
            trabajador.setIdCategoria(idCategorias);

            trabajadorID = (Integer) session.save(trabajador);
            tx.commit();

        }catch(HibernateException e){
            if (tx!=null) tx.rollback();
            e.printStackTrace();
        }finally{
            session.close();
        }

        return trabajador;
    }

    /**
     * Lista los trabajadores de la bbdd
     * @return
     */
    public List listaTrabajador(){
        return HibernateUtil.getSession().createCriteria(Trabajadorbbdd.class).list();
    }

    /**
     * Comprueba la existencia de un Trabajador en la bbdd
     * @param nombre
     * @param NIF
     * @param fechaAlta
     * @return
     */
    public int existeEnBBDDTrabajador(String nombre, String NIF, String fechaAlta){

        Session session = HibernateUtil.getSession();
        Transaction tx = null;

        boolean flag = false;
        int id = -1;
        try{
            tx = session.beginTransaction();
            this.trabs = listaTrabajador();

            for(Iterator iterator = trabs.iterator(); iterator.hasNext();){

                Trabajadorbbdd trabajador = (Trabajadorbbdd) iterator.next();

                if(trabajador.getNombre().equalsIgnoreCase(nombre) && trabajador.getNifnie().equalsIgnoreCase(NIF) && trabajador.getFechaAlta().toString().equalsIgnoreCase(fechaAlta)){
                    flag = true;
                    id = trabajador.getIdTrabajador();
                    break;
                }else{
                    flag = false;
                }

            }
            tx.commit();

        }catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }finally{
            session.close();
        }

        return id;
    }

    /**
     * Actualiza un trabajador de la bbdd
     * @param trabajadorID
     * @param idCategoria
     * @param idEmpresa
     * @param nombre
     * @param apellido1
     * @param apellido2
     * @param nifnie
     * @param email
     * @param fechaAlta
     * @param codigoCuenta
     * @param iban
     * @return
     */
    public Trabajadorbbdd updateTrabajador(Integer trabajadorID, int idCategoria, int idEmpresa, String nombre, String apellido1, String apellido2, String nifnie, String email, Date fechaAlta, String codigoCuenta, String iban){

        Session session = HibernateUtil.getSession();
        Transaction tx = null;
        Trabajadorbbdd trabajador = null;

        try{
            tx = session.beginTransaction();

            trabajador = (Trabajadorbbdd)session.get(Trabajadorbbdd.class, trabajadorID);
            if(trabajador != null) {

                trabajador.setIdCategoria(idCategoria);
                trabajador.setIdEmpresa(idEmpresa);
                trabajador.setNombre(nombre);
                trabajador.setApellido1(apellido1);
                trabajador.setApellido2(apellido2);
                trabajador.setNifnie(nifnie);
                trabajador.setEmail(email);
                trabajador.setFechaAlta(fechaAlta);
                trabajador.setCodigoCuenta(codigoCuenta);
                trabajador.setIban(iban);

                session.update(trabajador);

            }else{
                System.out.println("\tRepetido id: "+ trabajadorID);
            }
            tx.commit();
        }catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }finally{
            session.close();
        }

        return trabajador;
    }
}
