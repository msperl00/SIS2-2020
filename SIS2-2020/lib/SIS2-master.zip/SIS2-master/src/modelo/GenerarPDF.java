package modelo;


import com.itextpdf.io.font.FontConstants;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.*;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.property.HorizontalAlignment;
import com.itextpdf.layout.property.TextAlignment;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class GenerarPDF {

    private ArrayList<Nomina> nominas;
    private ArrayList<Trabajadorbbdd> trabajadores;
    private ArrayList<Empresas> empresas;

    //Fuente que vamos a usar
   private PdfFont font1;
    //Creacion de la fuente
   private  PdfFont font;

   private int anio;
   private int mes;
   private boolean extra;

    private static final String DEST = "resources/nominas";

    public GenerarPDF(TrabajadorUtils trabajadores, ArrayList<Nomina> nominas, int anio, int mes, boolean s) {
        this.trabajadores = trabajadores.getTrabList();
        this.empresas = trabajadores.getEmpresas();
        this.nominas = nominas;
        this.anio = anio;
        this.mes = mes;
        this.extra = s;

        Iterator<Nomina> in = this.nominas.iterator();

        Nomina actualNomina = null;

        while(in.hasNext()){
           actualNomina = in.next();
            Iterator<Trabajadorbbdd> it = this.trabajadores.iterator();

            Trabajadorbbdd actual = null;
            while(it.hasNext()){
                actual = it.next();
                if(actualNomina.getIdTrabajador() == actual.getIdTrabajador()){
                    Iterator<Empresas> ie = this.empresas.iterator();
                    Empresas actualEmpresa =null;

                    while(ie.hasNext()){
                        actualEmpresa = ie.next();
                        if(actual.getIdEmpresa() == actualEmpresa.getIdEmpresa()){
                            generarPDF(actual,actualNomina,actualEmpresa);

                        }
                    }
                }
            }

        }

       /* Trabajadorbbdd actual = null;
        Nomina actualNomina = null;

        while(it.hasNext()){
         actual = it.next();

            Iterator<Empresas> ie = this.empresas.iterator();
            boolean bandera = false;
            while(ie.hasNext() && !bandera){
                    actualEmpresa = ie.next();
                if(actual.getIdEmpresa().equals(actualEmpresa.getIdEmpresa())){
                    bandera = true;
                }
            }
            Iterator<Nomina> in = this.nominas.iterator();
            boolean bandera1 = false;
            while(in.hasNext() && !bandera1){
                actualNomina = in.next();
                if(actual.getIdTrabajador()==actualNomina.getIdTrabajador()){
                    bandera = true;
                }
            }

        }*/

      //  generarPDF(actual,actualNomina,actualEmpresa);
    }

    public void generarPDF(Trabajadorbbdd actual, Nomina nomina, Empresas empresa, String extra) {
        String dniEmpleado = actual.getNifnie();
        String nombreEmpleado = actual.getNombre();
        String apellidosEmpleado = actual.getApellido1() + actual.getApellido2();
        String mesNomina = String.valueOf(mes);
        String anioNomina = String.valueOf(anio);
        String diaNomina = String.valueOf(actual.getFechaAlta());

        try {

            // TODO PDF para todos los empleados segun los valores que recibe cada uno en   Tutils = trabajdores.
            String fileName = dniEmpleado + nombreEmpleado + apellidosEmpleado + mesNomina + anioNomina + diaNomina;
            Document documento = null;
            PdfWriter writer = null;
            PdfDocument pdfDoc = null;
            font = PdfFontFactory.createFont(FontConstants.TIMES_ROMAN);
            font1 = PdfFontFactory.createFont(FontConstants.TIMES_ITALIC);
            writer = new PdfWriter("resources/nominas/" + dniEmpleado + nombreEmpleado + apellidosEmpleado + anioNomina + mesNomina + diaNomina+ extra+".pdf");
            pdfDoc = new PdfDocument(writer);
            documento = new Document(pdfDoc, PageSize.LETTER);
            documento.setMargins(0, 20, 0, 10);

            /*******************
             * CUADRO DATOS DE LA EMPRESA
             *******************/
            añadirEncabezado(documento, actual,nomina,empresa);
            añadirEspaciado(documento, "Nomina: " + extra);
            añadirCuerpo(documento, actual, nomina, empresa);

            System.out.println("Nomina extra generada correctamente.");
            documento.close();

        } catch (FileNotFoundException e) {
            System.out.println("El fichero no ha sido encontrado.");
        } catch (NullPointerException e) {
            e.printStackTrace();
        } catch (IOException e) {
            System.out.println("El fichero no ha podido ser creado por algún motivo interno.");
        }

    }

    public void generarPDF(Trabajadorbbdd actual, Nomina nomina, Empresas empresa) {

        String dniEmpleado = actual.getNifnie();
        String nombreEmpleado = actual.getNombre();
        String apellidosEmpleado = actual.getApellido1() + actual.getApellido2();
        String mesNomina = String.valueOf(mes);
        String anioNomina = String.valueOf(anio);
        String diaNomina = String.valueOf(actual.getFechaAlta());
        String extra = getNombreMes(mes);



            try {

                // TODO PDF para todos los empleados segun los valores que recibe cada uno en   Tutils = trabajdores.
                String fileName = dniEmpleado + nombreEmpleado + apellidosEmpleado + mesNomina + anioNomina + diaNomina;
                Document documento = null;
                PdfWriter writer = null;
                PdfDocument pdfDoc = null;
                font = PdfFontFactory.createFont(FontConstants.TIMES_ROMAN);
                font1 = PdfFontFactory.createFont(FontConstants.TIMES_ITALIC);
                writer = new PdfWriter("resources/nominas/" + dniEmpleado + nombreEmpleado + apellidosEmpleado + anioNomina + mesNomina + diaNomina+ ".pdf");
                pdfDoc = new PdfDocument(writer);
                documento = new Document(pdfDoc, PageSize.LETTER);
                documento.setMargins(0, 20, 0, 10);

                /*******************
                 * CUADRO DATOS DE LA EMPRESA
                 *******************/
                 creamosCarpeta();
                añadirEncabezado(documento, actual,nomina,empresa);
                añadirEspaciado(documento, "Nomina: " + extra);
                añadirCuerpo(documento, actual, nomina, empresa);

                System.out.println("Nomina extra generada correctamente.");
                documento.close();

            } catch (FileNotFoundException e) {
                System.out.println("El fichero no ha sido encontrado.");
            } catch (NullPointerException e) {
                e.printStackTrace();
            } catch (IOException e) {
                System.out.println("El fichero no ha podido ser creado por algún motivo interno.");
            }





        }

    private String getNombreMes(int mes_nomina) {
        String mesString;
        switch (mes_nomina) {
            case 1:  mesString = "Enero";
                break;
            case 2:  mesString  = "Febrero";
                break;
            case 3:  mesString = "Marzo";
                break;
            case 4:  mesString = "Abril";
                break;
            case 5:  mesString = "Mayo";
                break;
            case 6:  mesString = buscaExtra("Junio") ;
                break;
            case 7:  mesString = "Julio";
                break;
            case 8:  mesString = "Agosto";
                break;
            case 9:  mesString = "Septiembre";
                break;
            case 10: mesString = "Octubre";
                break;
            case 11: mesString = "Noviembre";
                break;
            case 12: mesString = buscaExtra("Diciembre");
                break;
            default: mesString = "Invalid month";
                break;
        }
        return mesString;
    }

    private String buscaExtra(String mesNomina) {
        if (mesNomina == "Junio"){
            if(!extra) {
              //  System.out.println("\tEXTRA JUNIO");
                return "Extra Junio";
            }
            return "Junio";
        } else if (mesNomina == "Diciembre") {
            if(!extra){
                // System.out.println("\tEXTRA DICIEMBRE");
                return "Extra Diciembre";
            }
            return "extra Diciembre";
        }
        return "";
    }
    private String siExtra() {

            if(extra) {

                return "EXTRA";
            }


            return "";
    }

    private void añadirEspaciado(Document documento, String fecha) {

        Paragraph empty = new Paragraph(fecha);
        empty.setWidth(600);
        empty.setHeight(30);
        empty.setFontSize(20);
        empty.setFont(font);
        empty.setHorizontalAlignment(HorizontalAlignment.CENTER);
        documento.add(empty);
    }


    private Paragraph creacionParrafo(String sa, int anchura, int altura, PdfFont fuente){

        Paragraph nuevo = new Paragraph(sa);
        nuevo.setWidth(anchura);
        nuevo.setHeight(altura);
        nuevo.setFont(fuente);
        nuevo.setHorizontalAlignment(HorizontalAlignment.CENTER);
        nuevo.setTextAlignment(TextAlignment.CENTER);
        nuevo.setBorder(Border.NO_BORDER);

        return nuevo;

    }

    private void añadirCuerpo(Document documento, Trabajadorbbdd actual, Nomina nomina, Empresas empresa) throws IOException {

        // Creamos tabla una con especificacion y otra con valores.

        //  Paragraph inicio = new Paragraph();

        Table table = new Table(5);
        Cell cell = new Cell(1, 1).add(new Paragraph("Datos de Nomina"));
        table.addCell(cell);
        table.addCell(new Cell(1,1).setBorder(Border.NO_BORDER));
        table.addCell(new Cell(1,1).setBorder(Border.NO_BORDER));
        table.addCell(new Cell(1,1).setBorder(Border.NO_BORDER));
        table.addCell(new Cell(1,1).setBorder(Border.NO_BORDER));
        //Meto una sexta para alinear
        table.addCell(new Cell(1,1).setBorder(Border.NO_BORDER));


        cell.setTextAlignment(TextAlignment.CENTER);
        cell.setBackgroundColor(new DeviceRgb(140, 200, 8));

        table.addCell(creacionParrafo("Categoria:\n "+actual.getIdCategoria(),110,40,font1).setBorder(Border.NO_BORDER));
        table.addCell(creacionParrafo("IBAN:\n"+actual.getIban(),110,40,font1).setBorder(Border.NO_BORDER));
        table.addCell(creacionParrafo("Bruto Anual:\n+"+nomina.getBrutoNomina(),110,40,font1).setBorder(Border.NO_BORDER));
        table.addCell(creacionParrafo("Fecha de alta:\n"+actual.getFechaAlta(),110,40,font1).setBorder(Border.NO_BORDER));
        documento.add(table);

        Table table1 = new Table(5);
        table1.setBorder(Border.NO_BORDER);


        table1.addCell(new Cell(1,1).add(creacionParrafo("Trabajador: BASE",200,20,font)).setBorder(Border.NO_BORDER).setBackgroundColor(new DeviceRgb(140, 200, 8)));
        table1.addCell(new Cell(1,1).add(creacionParrafo("Cantidad",60,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo("Imp. Unit",60,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo("Dev",60,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo("Deducción",60,20,font)).setBorder(Border.NO_BORDER));

        // 1º Salario

        String cantidadSalarioBase = "30" ;
        String impUnitSalarioBase = String.valueOf(nomina.getImporteSalarioMes()/30);
        String devSalarioBase = String.valueOf(nomina.getImporteSalarioMes());
        String deduccionSalarioBase = "";
        table1.addCell(new Cell(1,1).add(creacionParrafo("Salario Base",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(cantidadSalarioBase,60,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(impUnitSalarioBase,60,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(devSalarioBase,60,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(deduccionSalarioBase,60,20,font)).setBorder(Border.NO_BORDER));


        //2º Prorrata
        String cantidadProrrata = "30";
        String impUnitProrrata = String.valueOf(nomina.getValorProrrateo()/30);
        String devProrrata = String.valueOf(nomina.getValorProrrateo());
        String deduccionProrrata = "";
        table1.addCell(new Cell(1,1).add(creacionParrafo("Prorrata",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(cantidadProrrata,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(impUnitProrrata,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(devProrrata,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(deduccionProrrata,50,20,font)).setBorder(Border.NO_BORDER));

        //3º Complemento

        String cantidadComplemento = "30";
        String impUnitComplemento = String.valueOf(nomina.getImporteComplementoMes()/30);
        String devComplemento= String.valueOf(nomina.getImporteComplementoMes());
        String deduccionComplemento = "";
        table1.addCell(new Cell(1,1).add(creacionParrafo("Complemento",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(cantidadComplemento,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(impUnitComplemento,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(devComplemento,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(deduccionComplemento,50,20,font)).setBorder(Border.NO_BORDER));

        //4º Antiguedad
        String cantidadAntiguedad = String.valueOf(nomina.getNumeroTrienios())+ " Trienios";
        String impUnitAntiguedad = String.valueOf(nomina.getImporteTrienios()/30);
        String devAntiguedad= String.valueOf(nomina.getImporteTrienios());
        String deduccionAntiguedad = " ";
        table1.addCell(new Cell(1,1).add(creacionParrafo("Antiguedad",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(cantidadAntiguedad,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(impUnitAntiguedad,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(devAntiguedad,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(deduccionAntiguedad,50,20,font)).setBorder(Border.NO_BORDER));

        //Espacio
        documento.add(new Table(1).setHeight(30).addCell(new Cell(1,1).setBorder(Border.NO_BORDER)).setBorder(Border.NO_BORDER));
        //ContingenciasGenerales
        String cantidadContingenciasGenerales = "4,7%";
        String impUnitContingenciasGenerales = String.valueOf(nomina.getImporteFormacionTrabajador());
        String devContingenciasGenerales= " ";
        String deduccionContingenciasGenerales = "";
        table1.addCell(new Cell(1,1).add(creacionParrafo("ContingenciasGenerales",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(cantidadContingenciasGenerales,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(impUnitContingenciasGenerales,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(devContingenciasGenerales,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(deduccionContingenciasGenerales,50,20,font)).setBorder(Border.NO_BORDER));

        //Desempleo
        String cantidadDesempleo = String.valueOf(nomina.getImporteDesempleoEmpresario());
        String impUnitDesempleo = String.valueOf(nomina.getImporteFormacionTrabajador());
        String devDesempleo= "";
        String deduccionDesempleo = "";
        table1.addCell(new Cell(1,1).add(creacionParrafo("Desempleo",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(cantidadDesempleo,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(impUnitDesempleo,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(devDesempleo,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(deduccionDesempleo,50,20,font)).setBorder(Border.NO_BORDER));

        //CuotaFormacion
        String cantidadCuotaFormacion = String.valueOf(nomina.getFormacionTrabajador());
        String impUnitCuotaFormacion = String.valueOf(nomina.getImporteFormacionTrabajador());
        String devCuotaFormacion= " ";
        String deduccionCuotaFormacion = "";
        table1.addCell(new Cell(1,1).add(creacionParrafo("CuotaFormacion",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(cantidadCuotaFormacion,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(impUnitCuotaFormacion,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(devCuotaFormacion,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(deduccionCuotaFormacion,50,20,font)).setBorder(Border.NO_BORDER));

        //IRPF
        String cantidadIRPF = String.valueOf(nomina.getImporteIrpf());
        String impUnitIRPF = String.valueOf(nomina.getIrpf());
        String devIRPF= String.valueOf(nomina.getImporteFormacionTrabajador());
        String deduccionIRPF = " ";
        table1.addCell(new Cell(1,1).add(creacionParrafo("IRPF",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(impUnitIRPF,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(devIRPF,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(" ",50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(cantidadIRPF,50,20,font)).setBorder(Border.NO_BORDER));


        //TotalDevoluciones Deduccion
        double totalDevoluciones =  nomina.getImporteFormacionTrabajador()+ nomina.getImporteIrpf() + nomina.getImporteDesempleoTrabajador()+ nomina.getImporteSeguridadSocialTrabajador();
        table1.addCell(new Cell(1,1).add(creacionParrafo("Total Devoluciones",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(" ",50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(" ",50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(" ",50,20,font)).setBorder(Border.NO_BORDER));

        table1.addCell(new Cell(1,1).add(creacionParrafo(String.valueOf(totalDevoluciones),50,20,font)).setBorder(Border.NO_BORDER));

        //TotalDevengos    Devo
        String totalDevengos = String.valueOf(nomina.getBrutoNomina());

        table1.addCell(new Cell(1,1).add(creacionParrafo("Total Devengos",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(" ",50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(" ",50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(totalDevengos,50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo("",50,20,font)).setBorder(Border.NO_BORDER));

        String liquidoAPercibir = String.valueOf(nomina.getLiquidoNomina());
        table1.addCell(new Cell(1,1).add(creacionParrafo("",200,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo(" ",50,20,font)).setBorder(Border.NO_BORDER));
        table1.addCell(new Cell(1,1).add(creacionParrafo("Liquido a percibir: ",100,20,font)));
        table1.addCell(new Cell(1,1).add(creacionParrafo(liquidoAPercibir,50,20,font)));

        documento.add(table1);

        Table tableFinal = new Table(2);

        tableFinal.addCell(new Cell(1,1).add(creacionParrafo("Empresa: BASE",200,18,font1)).setBorder(Border.NO_BORDER).setBackgroundColor(new DeviceRgb(140, 200, 100)));
        tableFinal.addCell(new Cell(1,1).add(creacionParrafo(" ",100,20,font)).setBorder(Border.NO_BORDER));

        tableFinal.addCell(new Cell(1,1).add(creacionParrafo("Base Empresario",100,18,font)).setBorder(Border.NO_BORDER));
        tableFinal.addCell(new Cell(1,1).add(creacionParrafo(String.valueOf(nomina.getBaseEmpresario())+"%",50,20,font)).setBorder(Border.NO_BORDER));

        tableFinal.addCell(new Cell(1,1).add(creacionParrafo("Desempleo",100,18,font)).setBorder(Border.NO_BORDER));
        tableFinal.addCell(new Cell(1,1).add(creacionParrafo(String.valueOf(nomina.getDesempleoEmpresario()+"%"),50,20,font)).setBorder(Border.NO_BORDER));

        tableFinal.addCell(new Cell(1,1).add(creacionParrafo("Formacion",100,18,font)).setBorder(Border.NO_BORDER));
        tableFinal.addCell(new Cell(1,1).add(creacionParrafo(String.valueOf(nomina.getFormacionEmpresario()+"%"),50,20,font)).setBorder(Border.NO_BORDER));

        tableFinal.addCell(new Cell(1,1).add(creacionParrafo("FOGASA",100,18,font)).setBorder(Border.NO_BORDER));
        tableFinal.addCell(new Cell(1,1).add(creacionParrafo(String.valueOf(nomina.getFogasaEmpresario()+"%"),50,20,font)).setBorder(Border.NO_BORDER));

        tableFinal.addCell(new Cell(1,1).add(creacionParrafo("Accidentes Trabajo",100,18,font)).setBorder(Border.NO_BORDER));
        tableFinal.addCell(new Cell(1,1).add(creacionParrafo(String.valueOf(nomina.getImporteAccidentesTrabajoEmpresario()+"%"),50,20,font)).setBorder(Border.NO_BORDER));

        tableFinal.addCell(new Cell(1,1).add(creacionParrafo("Total Empresario",100,18,font)));
        tableFinal.addCell(new Cell(1,1).add(creacionParrafo(String.valueOf(nomina.getCosteTotalEmpresario()),50,20,font)));
        documento.add(tableFinal);

    }


    private void añadirEncabezado(Document documento, Trabajadorbbdd actual, Nomina nomina, Empresas empresa) throws IOException {

        // Vamos a añadir dos celdas, una para el encabezado y otra para la imagen.
        Paragraph encabezado =new Paragraph("Nomina "+mes+"/"+anio).setFont(font).setTextAlignment(TextAlignment.CENTER);

        encabezado.setFontSize(25);
        encabezado.setWidth(400);
        encabezado.setHeight(50);
        encabezado.setHorizontalAlignment(HorizontalAlignment.CENTER);
        documento.add(new Cell(1,1).add(encabezado));

        Table tabEncabezado = new Table(3);
        tabEncabezado.setHorizontalAlignment(HorizontalAlignment.CENTER);
        tabEncabezado.setMarginTop(0);
        tabEncabezado.setHeight(100);
        tabEncabezado.setWidth(600);


        // 1º Encabezado
        Cell cellEncabezado = new Cell(1,1);
        cellEncabezado.setWidth(200);
        cellEncabezado.setMarginLeft(30);

        //Añadimos datos trabajdor a la tabla
        Paragraph nomTrabajador = new Paragraph(actual.getNombre()+actual.getApellido1()+actual.getApellido2());
        nomTrabajador.setFont(font1).setHorizontalAlignment(HorizontalAlignment.CENTER);
        Paragraph dni = new Paragraph("DNI"+actual.getNifnie());
        dni.setFont(font1).setHorizontalAlignment(HorizontalAlignment.CENTER);
        Paragraph dir1Trabajador = new Paragraph("Avenida de la facultad - 6");
        dir1Trabajador.setFont(font1).setHorizontalAlignment(HorizontalAlignment.CENTER);
        Paragraph dir2Trabajador = new Paragraph("24007 Leon");
        dir2Trabajador.setFont(font1).setHorizontalAlignment(HorizontalAlignment.CENTER);
        cellEncabezado.add(nomTrabajador);
        cellEncabezado.add(dni);
        cellEncabezado.add(dir1Trabajador);
        cellEncabezado.add(dir2Trabajador);

        tabEncabezado.addCell(cellEncabezado);


        // 2º Encabezado
        Cell cellImagen = new Cell();
        cellImagen.setBorder(Border.NO_BORDER);
        cellImagen.setHorizontalAlignment(HorizontalAlignment.CENTER);

        //Añadimos imagen a la tabla
        Image imagen = new Image(ImageDataFactory.create("resources/ico-nominas-min.png"));
        cellImagen.add(imagen.setAutoScale(true));
        cellImagen.setWidth(150);


        // 3º Encabezado
        Cell cellDerecha= new Cell(1,1);
        cellDerecha.setWidth(200);
        cellDerecha.setBorder(Border.NO_BORDER);

        //AÑadimos datos de empresa a la tabla
        Paragraph nom = new Paragraph(empresa.getNombre()).setHorizontalAlignment(HorizontalAlignment.CENTER);
        nom.setFont(font1);
        Paragraph cif = new Paragraph(empresa.getCif()).setHorizontalAlignment(HorizontalAlignment.CENTER);
        cif.setFont(font1);
        Paragraph dir1 = new Paragraph("Av/Asturias - 19").setHorizontalAlignment(HorizontalAlignment.CENTER);
        dir1.setFont(font1);
        Paragraph dir2 = new Paragraph("34008 Guardo").setHorizontalAlignment(HorizontalAlignment.CENTER);
        dir2.setFont(font1);
        cellDerecha.add(nom);
        cellDerecha.add(cif);
        cellDerecha.add(dir1);
        cellDerecha.add(dir2);

        //Añadimos a la tabla
        tabEncabezado.addCell(cellImagen);
        tabEncabezado.addCell(cellDerecha);

        // Encabezado implementado por IEventHandler
        documento.add(tabEncabezado);

    }
    private void creamosCarpeta() {
        // Creamos primero la carpeta Nominas, y si ya esta creada, la sobreescribimos
        File carpeta = new File("resources/nominas");
        if (!carpeta.exists()) {
            carpeta.mkdir();
        } else {
            System.out.println("Carpeta ya creada... ¿Quieres sobreescribirla?");
            Scanner sc = new Scanner(System.in);
            String cadena = sc.nextLine();
            if (cadena == "si" || cadena == "SI" || cadena == "Si") {
                {
                    System.out.println("Carpeta sobreescrita.");
                    carpeta.mkdir();
                }
            } else {
                System.out.println("Carpeta no se sobreescribe.");

            }
        }
    }


}
