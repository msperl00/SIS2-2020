package modelo;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Scanner;

public class HacerNomina {

    ArrayList<Trabajadorbbdd> trabajadores;

    private HashMap<String, Double> mapEmpresario;
    private HashMap<Integer, Integer> mapTrienios;
    private HashMap<Integer, Double> mapRetenciones;
    private HashMap<String, Double> mapTrabajadores;
    private CategoriasUtils categorias;


    private ArrayList<Nomina> nominas;
    private ArrayList<String> prorrateosLista;
    private ArrayList<Empresas> empresas;
    private TrabajadorUtils trabajadorUtils;

    public static int anio_nomina;
    public static int mes_nomina;
    private static double d_IRPF;
    private static double bruto_mensual;
    private static boolean prorrateo;

    /**
     * Constructor para Nomina
     * @param tUtils
     * @param categorias
     * @param mapTrabajadores
     * @param mapEmpresario
     * @param mapTrienios
     * @param mapRetenciones
     */
    public HacerNomina(TrabajadorUtils tUtils, CategoriasUtils categorias, HashMap<String, Double> mapTrabajadores, HashMap<String, Double> mapEmpresario,
                       HashMap<Integer, Integer> mapTrienios, HashMap<Integer, Double> mapRetenciones) {
        // En TrabajadorUtils tenemos los trabajadores, si tienen nómina prorrateada o no y las empresas a las que corresponden
        this.trabajadorUtils = tUtils;
        this.trabajadores = tUtils.getTrabList();
        this.prorrateosLista = tUtils.getProrrateoSoN();
        this.empresas = tUtils.getEmpresas();

        this.mapEmpresario = mapEmpresario;
        this.mapTrabajadores = mapTrabajadores;
        this.categorias = categorias;
        this.mapTrienios = mapTrienios;
        this.mapRetenciones = mapRetenciones;

        // Lectura de datos para el mes y año que se quiere comprobar la nómina
        Scanner sc = new Scanner(System.in);

        System.out.println("Introduce fecha (mm/aaaa): ");

        boolean flag = false;
        while(!flag) {

            try {
                String fecha = sc.nextLine();
                String[] caja = fecha.split("/");
                this.mes_nomina = Integer.parseInt(caja[0]);
                this.anio_nomina = Integer.parseInt(caja[1]);
                flag = true; // si se introduce mal, la excepcion salta antes de llegar aqui
            } catch (NumberFormatException e) {
                System.out.println("Datos introducidos erróneamente!. Prueba con (mm/aaaa).");
            }
        }
    }



    /**
     * Cálculo de la nómina
     */
    public void calcularNomina(){
        int contador = 0, meses, trienios;
        double base;
        double complemento;
        String nombreCategoria;
        nominas = new ArrayList<>();
        EmpresasUtils empresasUtils = trabajadorUtils.geteUtils();
        Calendar tra = Calendar.getInstance();
        int anio_alta = 0;
        int mes_alta = 0;

        // Recorremos toda la lista de trabajadores
        for (Trabajadorbbdd t : trabajadores) {

        	tra.setTime(t.getFechaAlta());
        	anio_alta = tra.get(Calendar.YEAR);
        	mes_alta = tra.get(Calendar.MONTH)+1; // empieza en 0

            // Si tiene una fecha de alta posterior a la fecha de nómina pedida no calculará la nómina
            if(anio_alta < anio_nomina || (anio_alta == anio_nomina && mes_alta <= mes_nomina)) {

	            Nomina n = new Nomina();    // creamos nómina

	            //System.out.println("Trabajador id: " + (++contador));
                ++contador;

	            nombreCategoria = categorias.getNombreCategoria(t.getIdCategoria());
	            base = categorias.getBaseCategoria(t.getIdCategoria());
	            complemento = categorias.getComplementoCategoria(t.getIdCategoria());

	            meses = calcularMeses(t.getFechaAlta());    // meses a la fecha de la nómina
                int dif = anio_nomina - anio_alta;

	            trienios = (((dif*12) / 12) / 3);  // número de trienios



                if(mes_alta >= mes_nomina && ((anio_nomina-anio_alta)%3==0) && trienios>1){
                    trienios--; // si la fecha de nómina pedida es igual al mes de alta no se aplicará ese trienio en esa nómina
                }
	            int ant = (dif*12) / 12;   // antigüedad en años
                int ant_calc = 0;
                int ant_pro = 0;

	            if (ant >= 3) {
                    ant_calc = mapTrienios.get(trienios);
	                if(cambiaTrienioEsteAnio(anio_alta)){

	                    if(mes_alta==1 && trienios==1){ // si es enero y 1 trienio se acaba de cambiar de trienio, no habrá más cambios
                            ant_pro = mapTrienios.get(trienios);
                        } else if(mes_nomina>=6 && mes_alta!=12 && mes_alta>=6){   // si es >= junio cobra la extra de junio?
                            ant_pro = mapTrienios.get(trienios+1);
                        } else {
                            ant_pro = mapTrienios.get(trienios);
                        }

	                }else{
                        ant_pro = mapTrienios.get(trienios);
                    }
                }

	             prorrateo = false;
	            if (prorrateosLista.get(contador - 1).equals("SI")) {
	                prorrateo = true;
	            }

	            double bruto_anual2 = getBrutoAnual2(base, complemento, prorrateo, anio_alta, mes_alta, ant, t.getFechaAlta());

	            double baseMes = base/14;
	            double complementoMes = complemento/14;
	            double antMes = ant_calc;
	             bruto_mensual = baseMes + complementoMes + antMes;

	            // Cálculo de base, OJO se realiza a visión año, ant se pone el último valor del trienio existente en ese año
                // ant_pro es el valor del ultimo trienio del año de nómina
                double bruto_12meses = bruto_mensual + baseMes/6 + complementoMes/6 + ant_pro/6.0;

                /*System.out.println("Base mes: " + baseMes);
                System.out.println("Complemento mes: " + complementoMes);
                System.out.println("Ant mes: " + antMes);
                System.out.println("Bruto mensual: " + bruto_mensual);
                System.out.println("BASE (12 meses): " + bruto_12meses);*/

	            double prorrata_extra = 0;

	            if (prorrateo) { //PRORRATEO SI

	                //calculamos la prorrata extra
	                prorrata_extra = baseMes/6 + complementoMes/6 + (ant_pro / 6.0);

	                bruto_mensual += prorrata_extra;
	                bruto_12meses = bruto_mensual; // aqui lo tenemos en cuenta para los descuentos

	            }

	            //Descuentos TRABAJADOR (porcentajes):
	            double ss = mapTrabajadores.get("Cuota obrera general TRABAJADOR");
	            double desempleo = mapTrabajadores.get("Cuota desempleo TRABAJADOR");
	            double formacion = mapTrabajadores.get("Cuota formación TRABAJADOR");
	            double IRPF = mapRetenciones.get(getRetencion(bruto_anual2));

	            //Descuento EMPRESARIO (porcentajes):
	            double contigencias_comunes = mapEmpresario.get("Contingencias comunes EMPRESARIO");
	            double FOGASA = mapEmpresario.get("Fogasa EMPRESARIO");
	            double desempleoE = mapEmpresario.get("Desempleo EMPRESARIO");
	            double formacionE = mapEmpresario.get("Formacion EMPRESARIO");
	            double accidentes = mapEmpresario.get("Accidentes trabajo EMPRESARIO");

	            //Descuento EMPRESARIO (valores):
	            double d_cc = bruto_12meses * (contigencias_comunes / 100);
	            double d_FOGASA = bruto_12meses * (FOGASA / 100);
	            double d_desempleoE = bruto_12meses * (desempleoE / 100);
	            double d_formacionE = bruto_12meses * (formacionE / 100);
	            double d_accidentes = bruto_12meses * (accidentes / 100);

	            double pago_empresario = d_cc + d_FOGASA + d_desempleoE + d_formacionE + d_accidentes;
	            double coste_total = bruto_mensual + pago_empresario;

	            //Descuentos TRABAJADOR(valores):
	            double d_ss = (ss * bruto_12meses) / 100;
	            double d_desempleo = (desempleo * bruto_12meses) / 100;
	            double d_formacion = (formacion * bruto_12meses) / 100;
	            d_IRPF = (IRPF * bruto_mensual) / 100;

	            double total_deducciones = d_desempleo + d_formacion + d_IRPF + d_ss;
	            double liquido_mensual = bruto_mensual - total_deducciones;






	            System.out.println("Importes a percibir - "+t.getNombre());
	            System.out.println("\tSalario base mes: " + base / 14);
	            System.out.println("\tProrrateo mes: " + prorrata_extra);
	            System.out.println("\tComplemento mes: " + complemento / 14);
	            System.out.println("\tAntigüedad (" + trienios + " trienios) mes: " + ant_calc);

	            System.out.println("Descuentos -"+t.getNombre());
	            System.out.println("\tSeguridad social (" + ss + "%) sobre " + bruto_12meses + " --> importe(" + d_ss + ")");
	            System.out.println("\tDesempleo (" + desempleo + "%) sobre " + bruto_12meses + " --> importe(" + d_desempleo + ")");
	            System.out.println("\tFormación (" + formacion + "%) sobre " + bruto_12meses + " --> importe(" + d_formacion + ")");
	            System.out.println("\tIRPF (" + IRPF + "%) sobre " + bruto_mensual + " --> importe(" + d_IRPF + ")");

	            System.out.println("Total deducciones - Trabajador: " +t.getNombre()+ total_deducciones);
	            System.out.println("Total devengos - Trabajador: " + bruto_mensual);
	            System.out.println("Líquido a percibir - Trabajador: " + liquido_mensual);

	            System.out.println("Pagos Empresario");
	            System.out.println("\tBASE: " + bruto_12meses);
	            System.out.println("\tContingencias comunes (" + contigencias_comunes + "%) --> importe(" + d_cc + ")");
	            System.out.println("\tDesempleo (" + desempleoE + "%) --> importe(" + d_desempleoE + ")");
	            System.out.println("\tFormacion (" + formacionE + "%) --> importe(" + d_formacionE + ")");
	            System.out.println("\tAccidentes de trabajo (" + accidentes + "%) --> importe(" + d_accidentes + ")");
	            System.out.println("\tFOGASA (" + FOGASA + "%) --> importe(" + d_FOGASA + ")");
	            System.out.println("\tTOTAL Empresario: " + pago_empresario);
	            System.out.println("Coste total trabajador: " + coste_total);


	            /*
	             * Se setean los valores obtenidos al objeto nomina
	             */
	            n.setMes(mes_nomina);
	            n.setAnio(anio_nomina);
	            n.setNumeroTrienios(trienios);
	            n.setImporteTrienios(ant_calc + 0.0);
	            n.setImporteSalarioMes(base / 14);
	            n.setImporteComplementoMes(complemento);
	            n.setValorProrrateo(prorrata_extra);
	            n.setBrutoAnual(bruto_anual2);
	            n.setIrpf(IRPF);
	            n.setImporteIrpf(d_IRPF);
	            n.setBaseEmpresario(pago_empresario);
	            n.setSeguridadSocialEmpresario(contigencias_comunes);
	            n.setImporteSeguridadSocialEmpresario(d_cc);
	            n.setDesempleoEmpresario(desempleoE);
	            n.setImporteDesempleoEmpresario(d_desempleoE);
	            n.setFormacionEmpresario(formacionE);
	            n.setImporteFormacionEmpresario(d_formacionE);
	            n.setAccidentesTrabajoEmpresario(accidentes);
	            n.setImporteAccidentesTrabajoEmpresario(d_accidentes);
	            n.setFogasaEmpresario(FOGASA);
	            n.setImporteFogasaEmpresario(d_FOGASA);
	            n.setSeguridadSocialTrabajador(ss);
	            n.setImporteSeguridadSocialTrabajador(d_ss);
	            n.setDesempleoTrabajador(desempleo);
	            n.setImporteDesempleoTrabajador(d_desempleo);
	            n.setFormacionTrabajador(formacion);
	            n.setImporteFormacionTrabajador(d_formacion);
	            n.setBrutoNomina(bruto_mensual);
	            n.setLiquidoNomina(liquido_mensual);
	            n.setCosteTotalEmpresario(coste_total);
	            n.setIdTrabajador(t.getIdTrabajador());


	            nominas.add(n);
        	} else {
                ++contador;
                /*System.out.println("\n************ IMPOSIBLE CALCULAR NÓMINA PARA EL TRABAJADOR CON ID ["+(++contador)+"], EXCEDE LA FECHA ************");
                System.out.println("\tFecha de alta: "+mes_alta+"/"+anio_alta);
                System.out.println("\tFecha de nómina pedida: "+mes_nomina+"/"+anio_nomina);
                System.out.println("\n-------------------\n");*/
            }
        }
    }

    public static boolean ProrrateoTrabajadores(){

        if (!prorrateo) {
            double liquido_mensual_extra = bruto_mensual - d_IRPF;
            double coste_total_extra = bruto_mensual;
            if (mes_nomina == 6) {
                System.out.println("\tEXTRA JUNIO");
                return true;
            } else if (mes_nomina == 12) {
                System.out.println("\tEXTRA DICIEMBRE");
                return true;
            }
        }
        return false;
    }

    /**
     * Se hace solo sobre el salario base, complementos y la antiguedad sin tener en cuenta las extras ni prorrateo
     * @param base
     * @param complemento
     * @param prorrateo
     * @param anio_alta
     * @param mes_alta
     * @param ant
     * @param fechaAlta
     * @return
     */
    private double getBrutoAnual2(double base, double complemento, boolean prorrateo, int anio_alta, int mes_alta, int ant, Date fechaAlta) {

        double brutoAnualTotal = 0;
        double anualSinAnt = base + complemento;
        double anualSinAnt14 = (base + complemento)/14;

        boolean cambiaTrienioEsteAnio = cambiaTrienioEsteAnio(anio_alta);
        boolean cambiaTrienioAnioSiguienteEfectivo = cambiaTrienioAnio(anio_alta, anio_nomina+1) && mes_alta<5 ;

        if(ant>=3) {

            double primerTrienio = 0, segundoTrienio = 0;

            int ant_valor = ant/3;

            if (cambiaTrienioEsteAnio || (cambiaTrienioAnioSiguienteEfectivo && prorrateo)) {

                ant_valor = (ant+1)/3; // para tratar caso que el cambio sea de 0 a 1

                if (ant_valor == 1) {
                    segundoTrienio = mapTrienios.get(1);    // caso particular, cambio de 0 a trienio 1
                } else {
                    primerTrienio = mapTrienios.get(ant_valor - 1);
                    segundoTrienio = mapTrienios.get(ant_valor);
                }

                if (prorrateo) {

                    if (cambiaTrienioEsteAnio) {
                        //System.out.println("CAMBIO ESTE");
                        // de enero a mayo
                        if (mes_alta < 6) {
                            // En caso de cambiar de 0 a 1 el primer trienio es 0, como el caso del id 42
                            brutoAnualTotal = mes_alta * (anualSinAnt14 + primerTrienio) + mes_alta * (anualSinAnt14 + segundoTrienio)/6 + (12 - mes_alta) * (anualSinAnt14 + segundoTrienio) + (12 - mes_alta) * (anualSinAnt14 + segundoTrienio)/6;
                        } else if (mes_alta >= 6 && mes_alta != 12) {
                            brutoAnualTotal = 5 * (anualSinAnt14 + primerTrienio) + 5 * (anualSinAnt14 + primerTrienio) / 6 + (mes_alta - 5) * (anualSinAnt14 + primerTrienio) + (mes_alta - 5) * (anualSinAnt14 + segundoTrienio) / 6 + (12 - mes_alta) * (anualSinAnt14 + segundoTrienio) + (12 - mes_alta) * (anualSinAnt14 + segundoTrienio) / 6;
                        } else {    // mes 12
                            // enero-mayo + junio-noviembre + diciembre(en este en la prorrata se cuenta con el valor siguiente trienio)
                            brutoAnualTotal = 12 * (anualSinAnt14 + primerTrienio) + 11 * (anualSinAnt14 + primerTrienio) / 6 + 1 * (anualSinAnt14 + segundoTrienio) / 6;
                        }

                    } else if (cambiaTrienioAnioSiguienteEfectivo) {
                        //System.out.println("CAMBIO SIGUIENTE 1os 6 meses efectivo");
                        // 11 meses*(anualSinAnt14 + primerTrienio) + 11 meses*(anualSinAnt14+primerTrienio)/6 + 1 mes con prorrata especial(anualSinAnt14+segundoTrienio)/6
                        brutoAnualTotal = 12 * (anualSinAnt14 + primerTrienio) + 11 * (anualSinAnt14 + primerTrienio) / 6 + 1 * (anualSinAnt14 + segundoTrienio) / 6;
                    }
                } else {
                    //System.out.println("SIN PRORRATEO CON CAMBIO");
                    if (mes_alta < 6) {
                        brutoAnualTotal = anualSinAnt + (mes_alta * primerTrienio) + ((12 - mes_alta) * segundoTrienio) + (segundoTrienio * 2);
                    } else if (mes_alta >= 6 && mes_alta < 12) {
                        brutoAnualTotal = anualSinAnt + (mes_alta * primerTrienio) + ((12 - mes_alta) * segundoTrienio) + primerTrienio + segundoTrienio;
                    } else if (mes_alta == 12) {
                        brutoAnualTotal = anualSinAnt + (14*primerTrienio);    // la ultima parte como si no estuviera da 0
                    }
                }

            } else {    //no hay cambio de trienio ni en este año ni en siguiente en 1os 6 meses

                double valorAnt = mapTrienios.get(ant_valor);
                brutoAnualTotal = anualSinAnt + 14 * valorAnt;
                //System.out.println("SIN cambio... valorAnt: " + valorAnt + ", trienios: " + ant_valor);
            }

        } else {    // sin antiguedad

            //System.out.println("SIN ANTIGUEDAD");

            int meses_extra_junio = tieneExtraJunio(fechaAlta);
            int meses_extra_diciembre = tieneExtraDiciembre(fechaAlta);

            if(!prorrateo) {
                //EXTRAS --> solo cuando NO haya prorrateo
                // extra de junio: se obtiene por los días trabahados entre 1/12 año anterior y 31/5 presente
                // extra de diciembre: dias trabajados entre 1/06 y 30/11

                //System.out.println("sinant sinpro, mes: "+ mes_alta);
                if(anio_alta == anio_nomina) {
                    int meses_1 = 0;
                    int meses_2 = 0;

                    if (mes_alta <= 6) {
                        meses_1 = 6 - mes_alta + 1;

                    } else if (mes_alta < 12) {
                        meses_1 = 6;
                        meses_2 = 12 - mes_alta + 1;
                    } else if (mes_alta == 12) {
                        meses_1 = 6;
                        meses_2 = 6;
                    }

                    //bruto_anual = (bruto_mensual*meses_1)+ (bruto_mensual*meses_2) + (bruto_mensual/(6/meses_extra_junio)) + (bruto_mensual/(6/meses_extra_diciembre));
                }


                double bruto_mensual = anualSinAnt / 14;
                //Cuando el año no es el de la nomina (1 o 2 años de ant)
                brutoAnualTotal = bruto_mensual*12 + (bruto_mensual/(6.0/meses_extra_junio)) + (bruto_mensual/(6.0/meses_extra_diciembre));

            }else{ // con prorrateo
               // System.out.println("sinant conpro, mes: "+mes_alta);

                //Cobra lo que ha trabajado este año
                int meses_trabajados = 0;
                if(anio_alta == anio_nomina){

                    double base12 = base/14;
                    double compl12 = complemento/14;
                    double bruto12 = base12 + compl12;

                    meses_trabajados = 12-mes_alta+1;
                    brutoAnualTotal = bruto12 *(meses_trabajados/12);
                    //bruto_anual = (bruto_anual/12) *meses_trabajados;
                }else if(mes_alta < 6 && cambiaTrienioEsteAnio(anio_alta-1)) {    // si cambia de trienio en primeros seis meses de año siguiente
                    //System.out.println("WTF");
                    brutoAnualTotal = anualSinAnt + (mapTrienios.get(1) + 0.0) / 6; // esta forzado segun los ejemplos de Rodrigo
                } else {
                    brutoAnualTotal = anualSinAnt;
                }

            }
        }

        return brutoAnualTotal;
    }

    /**
     * Obtiene la retención que corresponde según el bruto anual
     * @param bruto_anual bruto anual al que queremos sacar el IRPF
     * @return retencion
     */
    private int getRetencion(double bruto_anual){


        if(bruto_anual<12000){
            return 12000;
        }else{
            int rango = (int) (bruto_anual/1000);
            if(rango*1000 == bruto_anual){
                return rango*1000;
            }
            return (rango+1)*1000;
        }
    }

    /**
     * Devuelve true si hay cambio de trienio, y false si no
     * @param anio anio de la fecha de alta del trabajador
     * @return
     */
    private boolean cambiaTrienioEsteAnio(int anio) {

        int hoyAnio = this.anio_nomina;
        int trienio = hoyAnio - anio;

        if(trienio % 3 == 0){
            // Este año hay trienio
            return true;
        }
        return false;
    }

    /**
     * True si hay cambio de trienio, false si no
     * @param anioAlta
     * @param anioNomina
     * @return
     */
    private boolean cambiaTrienioAnio(int anioAlta, int anioNomina) {

        if((anioNomina-anioAlta) % 3 == 0){
            // Este año hay trienio
            return true;
        }
        // No hay trienio
        return false;
    }

    /**
     * Obtiene el número de meses trabajados para cobrar la extra de diciembre
     * 
     * @param alta fecha de alta
     * @return número de meses trabajados para extra de diciembre
     */
    private int tieneExtraDiciembre(Date alta){

        int meses_trabajados = 0;
        Calendar calendario = Calendar.getInstance();
        calendario.setTime(alta); // fecha es el Date de antes.
        int mes = calendario.get(Calendar.MONTH) + 1; // se le suma 1 porque empieza en 0
        int anio = calendario.get(Calendar.YEAR); //devuelve el año tal cual
        int hoyAnio = anio_nomina; // la fecha para la que queremos calcular la renta

        //la extra de diciembre se cobra si has trabajado de junio a noviembre
        if(anio == hoyAnio) {

            if (mes < 6) { //emepezo a trabajar antes de junio
                meses_trabajados = 6;
            } else {
                meses_trabajados = 6 - (mes -6); // s ele resta 6 al mes porque e rango es de 1 a 6
            }
        }else if(anio < hoyAnio){
            meses_trabajados = 6; // al ser otro año la cobra si o si
        }

        return meses_trabajados;
    }

    /**
     * Obtiene el número de meses trabajados para cobrar la extra de junio
     *
     * @param alta fecha de alta
     * @return número de meses trabajados para cobrar la extra de junio
     */
    private int tieneExtraJunio(Date alta){

        int meses_trabajados = 0;

        Calendar calendario = Calendar.getInstance();
        calendario.setTime(alta); // fecha es el Date de antes.

        int hoyAnio = this.anio_nomina; // la fecha para la que queremos calcular la renta

        int mes = calendario.get(Calendar.MONTH) + 1; // se le suma 1 porque empieza en 0
        int anio = calendario.get(Calendar.YEAR); // devuelve el año tal cual

        //Tiene extra en junio si empezo a trabajar en diciembre del año pasado

        if( anio<hoyAnio ) { // ha empezado a trabajar el año pasado

            meses_trabajados = 6;
        }else if(anio == hoyAnio){ //esta en este año y hay que calcular los meses para la extra

            if(mes>=6){ // si el mes que entro a trabajar es junio o superior no cobra la extra de junio
                meses_trabajados = 0; // significa que entro a trabajar este año, pero
            }else { // entro a trabajar antes de junio y se le descuentan los meses
                meses_trabajados = 6 - mes;
            }
        }
        return meses_trabajados;
    }

    /**
     * Calcula la antigüedad en meses de un empleado dada una fecha
     * @param alta fecha de alta
     * @return antigüedad en meses
     */
    private int calcularMeses(Date alta){

        try {
            //Fecha inicio en objeto Calendar
            Calendar startCalendar = Calendar.getInstance();
            startCalendar.setTime(alta);

            //Cálculo de meses para las fechas de inicio y finalización
            int startMes = (startCalendar.get(Calendar.YEAR) * 12) + startCalendar.get(Calendar.MONTH);
            int endMes = (this.anio_nomina * 12) + this.mes_nomina;
            //Diferencia en meses entre las dos fechas
            int diffMonth = endMes - startMes;
            return diffMonth;
        } catch (Exception e) {
            return 0;
        }
    }

    private String getNombreMes(int mes_nomina) {
        String mesString;
        switch (mes_nomina) {
            case 1:  mesString = "Enero";
                break;
            case 2:  mesString  = "Febrero";
                break;
            case 3:  mesString = "Marzo";
                break;
            case 4:  mesString = "Abril";
                break;
            case 5:  mesString = "Mayo";
                break;
            case 6:  mesString = "Junio";
                break;
            case 7:  mesString = "Julio";
                break;
            case 8:  mesString = "Agosto";
                break;
            case 9:  mesString = "Septiembre";
                break;
            case 10: mesString = "Octubre";
                break;
            case 11: mesString = "Noviembre";
                break;
            case 12: mesString = "Diciembre";
                break;
            default: mesString = "Invalid month";
                break;
        }
        return mesString;
    }

    /**
     * Get Nominas
     * @return nominas
     */
    public ArrayList<Nomina> getNominas() {
        return nominas;
    }
}