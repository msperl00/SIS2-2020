package modelo;

import java.util.ArrayList;

/**
 * Clase manejadora para la clase Empresas
 */
public class EmpresasUtils {

    private ArrayList<Empresas> empresasListUtils;

    public EmpresasUtils(ArrayList<Empresas> empresas) {
        this.empresasListUtils = empresas;
    }

    public ArrayList<Empresas> getEmpresasListUtils() {
        return empresasListUtils;
    }

    public String getNombreEmpresa(Integer idEmpresa) {
        for (Empresas e : empresasListUtils) {
            if (e.getIdEmpresa() == idEmpresa){
                return e.getNombre();
            }
        }
        return null;
    }

    public String getCifEmpresa(Integer idEmpresa) {
        for (Empresas e : empresasListUtils) {
            if (e.getIdEmpresa() == idEmpresa){
                return e.getCif();
            }
        }
        return null;
    }

    public Integer getIdEmpresa(String nombreEmpresa) {
        for (Empresas e : empresasListUtils) {
            if (e.getNombre().equals(nombreEmpresa)){
                return e.getIdEmpresa();
            }
        }
        return null;
    }
}
