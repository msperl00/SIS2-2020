package modelo;

import java.util.Iterator;
import java.util.List;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import util.HibernateUtil;

public class BBDDNomina {

    public void addNomina(Nomina nom){
        Session session = HibernateUtil.getSession();
        Transaction tx = null;
        Integer nominaID = null;

        try{
            tx = session.beginTransaction();

            Nomina nomina = new Nomina();
            nomina.setIdTrabajador(nom.getIdTrabajador());
            nomina.setMes(nom.getMes());
            nomina.setAnio(nom.getAnio());
            nomina.setNumeroTrienios(nom.getNumeroTrienios());
            nomina.setImporteTrienios(nom.getImporteTrienios());
            nomina.setImporteSalarioMes(nom.getImporteSalarioMes());
            nomina.setImporteComplementoMes(nom.getImporteComplementoMes());
            nomina.setValorProrrateo(nom.getValorProrrateo());
            nomina.setBrutoAnual(nom.getBrutoAnual());
            nomina.setIrpf(nom.getIrpf());
            nomina.setImporteIrpf(nom.getImporteIrpf());
            nomina.setBaseEmpresario(nom.getBaseEmpresario());
            nomina.setSeguridadSocialEmpresario(nom.getSeguridadSocialEmpresario());
            nomina.setImporteSeguridadSocialEmpresario(nom.getImporteSeguridadSocialEmpresario());
            nomina.setDesempleoEmpresario(nom.getDesempleoEmpresario());
            nomina.setImporteDesempleoEmpresario(nom.getImporteDesempleoEmpresario());
            nomina.setFormacionEmpresario(nom.getFormacionEmpresario());
            nomina.setImporteFogasaEmpresario(nom.getImporteFogasaEmpresario());
            nomina.setAccidentesTrabajoEmpresario(nom.getAccidentesTrabajoEmpresario());
            nomina.setImporteAccidentesTrabajoEmpresario(nom.getImporteAccidentesTrabajoEmpresario());
            nomina.setFogasaEmpresario(nom.getFogasaEmpresario());
            nomina.setImporteFogasaEmpresario(nom.getImporteFogasaEmpresario());
            nomina.setSeguridadSocialTrabajador(nom.getSeguridadSocialTrabajador());
            nomina.setImporteSeguridadSocialTrabajador(nom.getImporteSeguridadSocialTrabajador());
            nomina.setDesempleoTrabajador(nom.getDesempleoTrabajador());
            nomina.setImporteDesempleoTrabajador(nom.getImporteDesempleoTrabajador());
            nomina.setFormacionTrabajador(nom.getFormacionTrabajador());
            nomina.setImporteFormacionTrabajador(nom.getImporteFormacionTrabajador());
            nomina.setBrutoNomina(nom.getBrutoNomina());
            nomina.setLiquidoNomina(nom.getLiquidoNomina());
            nomina.setCosteTotalEmpresario(nom.getCosteTotalEmpresario());
            nominaID = (Integer) session.save(nomina);

            tx.commit();
        }catch(HibernateException e){
            if (tx!=null) tx.rollback();
            e.printStackTrace();
        } finally {
            session.close();
        }
    }

    public List listaNomina(){
        return HibernateUtil.getSession().createCriteria(Nomina.class).list();
    }

    public boolean existeEnBBDDNomina(int mes, int anio, int IdTrabajadorbbdd, double brutoNomina, double liquidoNomina){

        Session session = HibernateUtil.getSession();
        Transaction tx = null;
        List nominasList = null;
        boolean flag = false;

        try{

            tx = session.beginTransaction();
            nominasList = listaNomina();

            for(Iterator iterator = nominasList.iterator(); iterator.hasNext();){

                Nomina nomina = (Nomina) iterator.next();

                if(nomina.getMes() == mes && nomina.getAnio() == anio && nomina.getIdTrabajador() == IdTrabajadorbbdd && nomina.getBrutoNomina() == brutoNomina && nomina.getLiquidoNomina() == liquidoNomina){

                    flag = true;
                    break;

                }else{
                    flag = false;
                }
            }
            tx.commit();

        }catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }finally{
            session.close();
        }
        return flag;
    }


    public void updateNomina(Nomina nom){
        Session session = HibernateUtil.getSession();
        Transaction tx = null;

        try{

            tx = session.beginTransaction();

            Nomina nomina = (Nomina)session.get(Nomina.class, nom.getIdNomina());

            nomina.setIdTrabajador(nom.getIdTrabajador());
            nomina.setMes(nom.getMes());
            nomina.setAnio(nom.getAnio());
            nomina.setNumeroTrienios(nom.getNumeroTrienios());
            nomina.setImporteTrienios(nom.getImporteTrienios());
            nomina.setImporteSalarioMes(nom.getImporteSalarioMes());
            nomina.setImporteComplementoMes(nom.getImporteComplementoMes());
            nomina.setValorProrrateo(nom.getValorProrrateo());
            nomina.setBrutoAnual(nom.getBrutoAnual());
            nomina.setIrpf(nom.getIrpf());
            nomina.setImporteIrpf(nom.getImporteIrpf());
            nomina.setBaseEmpresario(nom.getBaseEmpresario());
            nomina.setSeguridadSocialEmpresario(nom.getSeguridadSocialEmpresario());
            nomina.setImporteSeguridadSocialEmpresario(nom.getImporteSeguridadSocialEmpresario());
            nomina.setDesempleoEmpresario(nom.getDesempleoEmpresario());
            nomina.setImporteDesempleoEmpresario(nom.getImporteDesempleoEmpresario());
            nomina.setFormacionEmpresario(nom.getFormacionEmpresario());
            nomina.setImporteFogasaEmpresario(nom.getImporteFogasaEmpresario());
            nomina.setAccidentesTrabajoEmpresario(nom.getAccidentesTrabajoEmpresario());
            nomina.setImporteAccidentesTrabajoEmpresario(nom.getImporteAccidentesTrabajoEmpresario());
            nomina.setFogasaEmpresario(nom.getFogasaEmpresario());
            nomina.setImporteFogasaEmpresario(nom.getImporteFogasaEmpresario());
            nomina.setSeguridadSocialTrabajador(nom.getSeguridadSocialTrabajador());
            nomina.setImporteSeguridadSocialTrabajador(nom.getImporteSeguridadSocialTrabajador());
            nomina.setDesempleoTrabajador(nom.getDesempleoTrabajador());
            nomina.setImporteDesempleoTrabajador(nom.getImporteDesempleoTrabajador());
            nomina.setFormacionTrabajador(nom.getFormacionTrabajador());
            nomina.setImporteFormacionTrabajador(nom.getImporteFormacionTrabajador());
            nomina.setBrutoNomina(nom.getBrutoNomina());
            nomina.setLiquidoNomina(nom.getLiquidoNomina());
            nomina.setCosteTotalEmpresario(nom.getCosteTotalEmpresario());

            session.update(nomina);
            tx.commit();

        }catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }finally{
            session.close();
        }
    }
}
