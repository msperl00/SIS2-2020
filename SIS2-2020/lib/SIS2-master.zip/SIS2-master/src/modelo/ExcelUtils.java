package modelo;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.math.BigInteger;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

/**
 * Clase para el acceso, manejo, escritura y lectura de la Hoja de Excel
 */
public class ExcelUtils {
    private CategoriasUtils categoriasUtils;
    private EmpresasUtils empresasUtils;
    private TrabajadorUtils trabajadorUtils;

    // mirar mejor otro código de aquí: https://www.codejava.net/coding/how-to-read-excel-files-in-java-using-apache-poi
    public TrabajadorUtils readExcelFile(File excelFile){
        InputStream excelStream = null;

        ArrayList<Trabajadorbbdd> trabajadores = new ArrayList<Trabajadorbbdd>();
        ArrayList<Empresas> empresas = new ArrayList<>();
        ArrayList<String> prorrateoSoN = new ArrayList<>();
        empresasUtils = new EmpresasUtils(empresas);
        ArrayList<String> paises = new ArrayList<>();

        try {
            excelStream = new FileInputStream(excelFile);

            // High level representation of a workbook.
            // Representación del más alto nivel de la hoja excel.

            Workbook workbook = new XSSFWorkbook(excelStream);

            // We chose the sheet is passed as parameter.
            // Elegimos la hoja que se pasa por parámetro.
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();
            Trabajadorbbdd trabajador = null;
            HashMap<String, String> mapEmpresas = new HashMap<>();
            int idEmpresa = 0;

            while(rowIterator.hasNext()){
                trabajador = new Trabajadorbbdd();
                Row row = rowIterator.next();
                String empresa = "";

                if (row.getRowNum() == 0){
                    // la primera fila la descartamos, es la que tiene los titulos
                    continue;
                } else {
                    int j = 0;

                    for(int i=0; i<row.getLastCellNum(); i++) {
                        Cell cell = row.getCell(i, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

                        switch (j){
                            case 0:
                                trabajador.setNombre(cell.getStringCellValue());
                                break;
                            case 1:
                                trabajador.setApellido1(cell.getStringCellValue());
                                break;
                            case 2:
                                trabajador.setApellido2(cell.getStringCellValue());
                                break;
                            case 3:
                                trabajador.setNifnie(cell.getStringCellValue());
                                break;
                            case 4:
                                trabajador.setFechaAlta( new java.sql.Date(cell.getDateCellValue().getTime()));
                                break;
                            case 5:
                                trabajador.setEmail(cell.getStringCellValue());
                                break;
                            case 6:
                                empresa = cell.getStringCellValue();
                                break;
                            case 7:
                                if(!mapEmpresas.containsKey(empresa)){
                                    idEmpresa++;

                                    mapEmpresas.put(empresa, cell.getStringCellValue());

                                    // Guardamos las empresas
                                    Empresas e = new Empresas();
                                    e.setIdEmpresa(idEmpresa);
                                    e.setNombre(empresa);
                                    e.setCif(mapEmpresas.get(empresa));
                                    empresas.add(e);
                                }
                                break;
                            case 8:
                                prorrateoSoN.add(cell.getStringCellValue());
                                break;
                            case 9:
                                trabajador.setIdCategoria(categoriasUtils.asociarConIdCategoria(cell.getStringCellValue()));
                                break;
                            case 10:
                                trabajador.setCodigoCuenta(cell.getStringCellValue());
                                break;
                            case 11:
                                //trabajador.setPais(cell.getStringCellValue());
                                paises.add(cell.getStringCellValue());
                                break;
                            case 12:
                                trabajador.setIban(cell.getStringCellValue());
                                break;
                            default:

                                break;
                        }
                        j++;
                    }
                }


                // Añadimos el id de empresa correspondiente al trabajador
                trabajador.setIdEmpresa(empresasUtils.getIdEmpresa(empresa));
                // Añadimos el trabajador a la lista
                trabajadores.add(trabajador);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


/*
        for (Empresas e : empresas){
            System.out.println(e.getIdEmpresa() + " " + e.getNombre() + " " + e.getCif());
        }
*/
        trabajadorUtils = new TrabajadorUtils(trabajadores, prorrateoSoN, empresasUtils, paises);
        return trabajadorUtils;
    }

    /**
     * Carga los datos relacionados con las categorías
     * @param excelFile
     * @return
     */
    public HashMap<String, WrapperCategoria> cargarCategorias(File excelFile) {

        HashMap<String, WrapperCategoria> mapCategorias = new HashMap<>();

        try {
            FileInputStream excelStream = new FileInputStream(excelFile);
            XSSFWorkbook workbook = new XSSFWorkbook(excelStream);

            // Elegimos la hoja 2
            XSSFSheet sheet = workbook.getSheetAt(1);

            for (int i = 1; i < 15; i++) {
                XSSFRow row = sheet.getRow(i);
                mapCategorias.put(row.getCell(0).getStringCellValue(), new WrapperCategoria(row.getCell(1).getNumericCellValue(), row.getCell(2).getNumericCellValue()));
                /*System.out.println("pruebas: ");
                System.out.println("Categorias: "+row.getCell(0).getStringCellValue());
                System.out.println("Salario base: "+row.getCell(1).getNumericCellValue());
                System.out.println("Complementos: "+row.getCell(2).getNumericCellValue());
            */}

        } catch (IOException e) {
            e.printStackTrace();
        }

        return mapCategorias;
    }

    public void setCatUtils(CategoriasUtils catUtils) {
        this.categoriasUtils = catUtils;
    }

    /**
     * Clase utilizada para las categorías
     */
    public class WrapperCategoria {
        private Integer base;
        private Integer complementos;

        public WrapperCategoria(Double base, Double complementos){
            this.base = base.intValue();
            this.complementos = complementos.intValue();
        }
        public Integer getBase(){
            return this.base;
        }
        public Integer getComplementos() {
            return this.complementos;
        }
    }

    /**
     * Carga los datos seleccionados de la hoja 2 en una estructura de datos
     * @param excelFile
     * @param group
     * @return
     */
    public HashMap<?, ?> cargarHoja2(File excelFile, String group) {

        HashMap<String, Double> map = new HashMap<>();
        HashMap<Integer, Integer> mapTrienios = new HashMap<>();
        HashMap<Integer, Double> mapRetenciones = new HashMap<>();

        try {
            FileInputStream excelStream = new FileInputStream(excelFile);
            XSSFWorkbook workbook = new XSSFWorkbook(excelStream);

            // Elegimos la hoja 2
            XSSFSheet sheet = workbook.getSheetAt(1);

            int startRow = 0;
            int endRow = 0;
            int keyColumn = 0;

            if (group.equals("trabajador")) {
                startRow = 17;
                endRow = 19;
                keyColumn = 0;
            } else if (group.equals("empresario")){
                startRow = 20;
                endRow = 24;
                keyColumn = 0;
            } else if (group.equals("trienios")){
                startRow = 18;
                endRow = 35;
                keyColumn = 2;
            } else if (group.equals("retenciones")){
                startRow = 1;
                endRow = 49;
                keyColumn = 5;
            }

            for (int i = startRow; i < endRow + 1; i++) {
                XSSFRow row = sheet.getRow(i);
                if (group.equals("trienios")){
                    mapTrienios.put((int)row.getCell(keyColumn).getNumericCellValue(),(int) row.getCell(keyColumn + 1).getNumericCellValue());
                } else if (group.equals("retenciones")) {
                    mapRetenciones.put((int)row.getCell(keyColumn).getNumericCellValue(), row.getCell(keyColumn + 1).getNumericCellValue());
                } else {
                    map.put(row.getCell(keyColumn).getStringCellValue(), row.getCell(keyColumn + 1).getNumericCellValue());
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (group.equals("trienios")) {
            return mapTrienios;
        } else if (group.equals("retenciones")){
            return mapRetenciones;
        } else {
            // trabajador o empresario
            return map;
        }
    }

        /**
     * Actualizar archivo excel en una celda específica
     * @param row
     * @param col
     * @param nuevoValor
     * @throws IOException
     */
    public static void escribirExcelCell(int row, int col, String nuevoValor) throws IOException {
        try {
            FileInputStream file = new FileInputStream("resources/SistemasInformacionII.xlsx");


            XSSFWorkbook workbook = new XSSFWorkbook(file);
            XSSFSheet sheet = workbook.getSheetAt(0);

            //Update the value of cell
            Cell cell = sheet.getRow(row).getCell(col, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);

            System.out.println("nuevo valor:"+ nuevoValor);
            System.out.println(cell);
            cell.setCellValue(nuevoValor);

            file.close();

            FileOutputStream outFile =new FileOutputStream(new File("resources/SistemasInformacionII.xlsx"));
            workbook.write(outFile);
            outFile.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Actualizar archivo excel en toda una columna, aquellos valores que estén sin nada
     * @param trabajadores
     * @param column
     */
    private void updateExcelByColumn(ArrayList<Trabajadorbbdd> trabajadores, int column) {

        try {
            XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream("resources/SistemasInformacionII.xlsx"));

            XSSFSheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();

                if (row.getRowNum() == 0) {
                    // la primera fila la descartamos, es la que tiene los titulos
                    continue;
                } else {
                    // Get the cell
                    Cell cell = row.getCell(column, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    // OJO!! Rellenamos con nuevo contenido si está vacía

                    if(column==5 && cell.getStringCellValue().equals("")){
                        cell.setCellValue(trabajadores.get(row.getRowNum() - 1).getEmail());
                    } else if (column==10){
                        cell.setCellValue(trabajadores.get(row.getRowNum() - 1).getCodigoCuenta());
                    } else if (column==12){
                        cell.setCellValue(trabajadores.get(row.getRowNum() - 1).getIban());
                    }

                }
            }

            FileOutputStream outFile = new FileOutputStream(new File("resources/SistemasInformacionII.xlsx"));
            workbook.write(outFile);    // escribimos todos los cambios
            outFile.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Fichero excel actualizado correctamente!");
    }

    /**
     * Crea un correo según el patrçon indicado si no tiene uno asignado ya
     * @param trabajadores
     */
    public void crearCorreo(ArrayList<Trabajadorbbdd> trabajadores){
        //la estrategia que voy a adoptar va a ser de generar todos los correos de una vez segun el arraylist de trabajadores

        ArrayList<String> emails = new ArrayList<String>();

        //Para cada trabajador voy a crear un correo como se muestran en el enunciado y despues buscando en "creados" si existe ya que ahi estara el ultimo numero de cada tipo
        String nick = "";
        for(Trabajadorbbdd t : trabajadores){

            // Si no tiene correo lo creamos, si ya tiene lo añadimos a la lista directamente
            if(t.getEmail().equals("")){
                if(t.getApellido2().length() < 1){
                    nick = nick + t.getApellido1().substring(0,1) + t.getNombre().substring(0,1);
                } else {
                    nick = nick + t.getApellido1().substring(0,1) + t.getApellido2().substring(0,1) + t.getNombre().substring(0,1);

                }
                nick = nick.toLowerCase();
                String emailNuevo = nick+obtenerNumero(nick, emails);
                emailNuevo = emailNuevo+"@"+ empresasUtils.getNombreEmpresa(t.getIdEmpresa()).toLowerCase()+".es";

                // Quitamos las posibles tildes si hubiera
                emailNuevo = stripAccents(emailNuevo);

                //System.out.println("El email nuevo es: "+emailNuevo+"\nNombre y apellidos: "+t.getNombre()+" " + t.getApellido1() +" " + t.getApellido2()+"\n");
                t.setEmail(emailNuevo);
            }

            emails.add(t.getEmail());

            nick = "";
        }

        // Añadimos al excel los nuevos correos ( columna 5) [0-n]
        updateExcelByColumn(trabajadores, 5);
    }

    /**
     * Quita las tildes de una cadena
     * @param s
     * @return
     */
    private String stripAccents(String s) {
        s = Normalizer.normalize(s, Normalizer.Form.NFD);
        s = s.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
        return s;
    }

    /**
     * Método que saca el número para el nickname de correo pasado
     * @param nick
     * @param creados
     * @return el numero que corresponde a unas iniciales dadas segun el array de emails
     */
    private String obtenerNumero(String nick, ArrayList<String> creados) {

        String numeros ="-1";
        boolean encontrado = false;
        for(String e : creados){
            int arrobaPos = e.indexOf("@");
            //System.out.println(email);
            //se compara las iniciales de busqueda, y si ese numero es el mayor con esas iniciales.
            //System.out.println("email equals: ? " + email + " =? " + e.substring(0,arrobaPos-2));
            //System.out.println("integer " + e.substring(arrobaPos-2,arrobaPos) + " ?> " + numeros);
            if(nick.equals(e.substring(0,arrobaPos-2)) && (Integer.parseInt(e.substring(arrobaPos-2,arrobaPos)) > Integer.parseInt(numeros))) { //si tienen las misma iniciales
                numeros = e.substring(arrobaPos-2, arrobaPos);
                encontrado = true;
            }

        }

        if(encontrado){
            int nuevoNumero = 1 + Integer.parseInt(numeros);
            if(nuevoNumero < 10){
                numeros = "0" + String.valueOf(nuevoNumero);
            }else{
                numeros = String.valueOf(nuevoNumero);
            }
            // System.out.println("el numero calculado es: "+numeros);
            return numeros;
        }
        return "00";
    }

    /**
     * Método que compueba si los CCC son correctos, en su defecto los actualiza
     * @param trabajadores
     * @return  lista con los trabajadores con CCC erróneos
     */
    public ArrayList<Trabajadorbbdd> comprobarCCC(ArrayList<Trabajadorbbdd> trabajadores) {

        ArrayList<Trabajadorbbdd> erroresCCC = new ArrayList<>();
        int row = 1;

        for (Trabajadorbbdd t: trabajadores) {
            String controlCuenta = t.getCodigoCuenta().substring(8, 10);
            String digitoControlCorrecto = calculaDigitoControl(t.getCodigoCuenta());

            if (!digitoControlCorrecto.equals(controlCuenta) ) {
                String cuentaCorregida = t.getCodigoCuenta().substring(0,8) + digitoControlCorrecto + t.getCodigoCuenta().substring(10);
                System.out.println("CCC mal/bien (fila: " + (row+1) + "): " + "\n"+ t.getCodigoCuenta() + "\n" + cuentaCorregida);

                Trabajadorbbdd nuevo = new Trabajadorbbdd();
                // Creamos nuevo trabajador que almacenar en errores
                nuevo.setIdTrabajador(row);
                nuevo.setCodigoCuenta(t.getCodigoCuenta());
                nuevo.setNombre(t.getNombre());
                nuevo.setApellido1(t.getApellido1());
                nuevo.setApellido2(t.getApellido2());
                nuevo.setIdEmpresa(t.getIdEmpresa());

                // Calculamos IBAN
                t.setCodigoCuenta(cuentaCorregida);
                t.setIban(calcularIBAN(t, trabajadorUtils.getPaises().get(row-1)));
                nuevo.setIban(t.getIban());

                erroresCCC.add(nuevo);

            }else{
                t.setIban(calcularIBAN(t, trabajadorUtils.getPaises().get(row-1)));
            }

            row++;
        }

        updateExcelByColumn(trabajadores, 10); // Actualizamos Excel con CCC correctos
        updateExcelByColumn(trabajadores, 12); // Actualizamos Excel con IBAN

        return erroresCCC;
    }

    /**
     * Cálculo del código IBAN según el CCC
     * @param paises
     * @param trabajador
     * @return
     */
    public String calcularIBAN(Trabajadorbbdd trabajador, String pais) {

        String preIban =
                trabajador.getCodigoCuenta()+
                damePesoIBAN(pais.charAt(0))+
                damePesoIBAN(pais.charAt(1))+
                "00";
        BigInteger ccc = new BigInteger(preIban);
        BigInteger noventaysiete = new BigInteger("97");
        ccc = ccc.mod(noventaysiete);
        int dcIb = ccc.intValue();
        dcIb = 98 - dcIb;

        String ceros = ponCerosIzquierda(Integer.toString(dcIb),2);
        return pais+ceros+trabajador.getCodigoCuenta();
    }

    private String ponCerosIzquierda(String str,int longitud){
        String ceros = "";
        if(str.length()<longitud){
            for(int i=0;i<(longitud-str.length());i++){
                ceros = ceros + '0';
            }
            str = ceros + str;
        }

        return str;
    }

    private String damePesoIBAN(char letra){
        String peso = "";
        letra = Character.toUpperCase(letra);
        switch (letra){
            case 'A': peso = "10";
                break;
            case 'B': peso = "11";
                break;
            case 'C': peso = "12";
                break;
            case 'D': peso = "13";
                break;
            case 'E': peso = "14";
                break;
            case 'F': peso = "15";
                break;
            case 'G': peso = "16";
                break;
            case 'H': peso = "17";
                break;
            case 'I': peso = "18";
                break;
            case 'J': peso = "19";
                break;
            case 'K': peso = "20";
                break;
            case 'L': peso = "21";
                break;
            case 'M': peso = "22";
                break;
            case 'N': peso = "23";
                break;
            case 'O': peso = "24";
                break;
            case 'P': peso = "25";
                break;
            case 'Q': peso = "26";
                break;
            case 'R': peso = "27";
                break;
            case 'S': peso = "28";
                break;
            case 'T': peso = "29";
                break;
            case 'U': peso = "30";
                break;
            case 'V': peso = "31";
                break;
            case 'W': peso = "32";
                break;
            case 'X': peso = "33";
                break;
            case 'Y': peso = "34";
                break;
            case 'Z': peso = "35";
                break;
        }
        return peso;
    }

    /**
     * Cálculo del dígito de control según el CCC
     * @param cuenta
     * @return
     */
    private String calculaDigitoControl(String cuenta) {

        // parte izquierda
        String banco = "00"+cuenta.substring(0,8);

        int suma = Integer.parseInt(banco.substring(0, 1)) +
                (Integer.parseInt(banco.substring(1, 2)) * 2) +
                (Integer.parseInt(banco.substring(2, 3)) * 4) +
                (Integer.parseInt(banco.substring(3, 4)) * 8) +
                (Integer.parseInt(banco.substring(4, 5)) * 5) +
                (Integer.parseInt(banco.substring(5, 6)) * 10) +
                (Integer.parseInt(banco.substring(6, 7)) * 9) +
                (Integer.parseInt(banco.substring(7, 8)) * 7) +
                (Integer.parseInt(banco.substring(8, 9)) * 3) +
                (Integer.parseInt(banco.substring(9, 10)) * 6);

        int control1 = 11 - (suma%11);
        if (control1==10){
            control1=1;
        } else if (control1==11) {
            control1=0;
        }

        // parte dcha
        suma = Integer.parseInt(cuenta.substring(10,11))*1+
                Integer.parseInt(cuenta.substring(11,12))*2+
                Integer.parseInt(cuenta.substring(12,13))*4+
                Integer.parseInt(cuenta.substring(13,14))*8+
                Integer.parseInt(cuenta.substring(14,15))*5+
                Integer.parseInt(cuenta.substring(15,16))*10+
                Integer.parseInt(cuenta.substring(16,17))*9+
                Integer.parseInt(cuenta.substring(17,18))*7+
                Integer.parseInt(cuenta.substring(18,19))*3+
                Integer.parseInt(cuenta.substring(19,20))*6;

        Integer control2 = 11 - (suma%11);

        if (control2==10) {
            control2 = 1;
        } else if (control2==11) {
            control2 = 0;
        }

        // digito de control completo
        String c1 = Integer.toString(control1);
        String c2 = Integer.toString(control2);
        return c1+c2;
    }

    // TODO optimizar escritura-acceso a excel
    /**
     * Comprueba si los dni de los trabajadores son correctos, en su defecto los actualiza
     * @param trabajadores
     * @return
     */
    public ArrayList<Trabajadorbbdd> comprobarDnis(ArrayList<Trabajadorbbdd> trabajadores) {

        int row = 1;  // Empezamos en fila 1

        ArrayList<Trabajadorbbdd> errores = new ArrayList<>();
        ArrayList<String> dnisSinDuplicados = new ArrayList<>();

        for (Trabajadorbbdd t : trabajadores) {
            String dniCorrecto = calculaLetra(t.getNifnie());

            boolean duplicado = dnisSinDuplicados.contains(t.getNifnie());
            boolean esBlanco = dniCorrecto.equals("");

            if(!duplicado && !esBlanco) {
                t.setIdTrabajador(row);
                dnisSinDuplicados.add(t.getNifnie());
            }

            // añadimos a errores el blanco o el segundo de los duplicados
            if (esBlanco || duplicado){
                t.setIdTrabajador(row);
                errores.add(t);
            }


            if (!t.getNifnie().equals(dniCorrecto)){
                // OJO! en la impresion no se coge el indice real de excel, row es el indice correcto
                //System.out.println("Está mal: fila("+(row+1)+") mal/bien - " + t.getNifnie() + "/" + dniCorrecto);
                try {
                    escribirExcelCell(row, 3, dniCorrecto);
                    System.out.println("Corregido dni en: fila("+(row+1)+")");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            row++;
        }

        System.out.println("Corregidos DNI incorrectos!");

        /*System.out.println("dnisSinDuplicados");
        for(String t : dnisSinDuplicados){
            System.out.println(t.toString());
        }
        System.out.println("nº dnis sin duplicar: " + dnisSinDuplicados.size());
        */

        /*System.out.println("ERRORES");
        for(Trabajadorbbdd t : errores){
            System.out.println(t.toString());
        }*/
        return errores;
    }

    public String calculaLetra(String dni) {
        if(dni.equals("")) {
            return "";
        } else {
            // Cogemos la primera parte sin la letra para poder retornarla al final
            String primeraParte = dni.substring(0,(dni.length()-1));

            String juegoCaracteres="TRWAGMYFPDXBNJZSQVHLCKE";

            char primera = dni.charAt(0);

            if(Character.isLetter(primera)){
                if(primera == 'X') {
                    dni = "0"+dni.substring(1);
                } else if (primera == 'Y') {
                    dni = "1"+dni.substring(1);
                } else if (primera == 'Z'){
                    dni = "2"+dni.substring(1);
                } // ?? posible error si mete otra letra

            }

            String numeros = dni.substring(0,(dni.length()-1));

            int num = Integer.parseInt(numeros);
            int modulo = num % 23;

            char letra = juegoCaracteres.charAt(modulo);

            return (primeraParte+letra);
        }

    }

    // TODO optimizar código para escritura archivos errores xml
    public void crearErroresDniXML(ArrayList<Trabajadorbbdd> erroneos){

        try {

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // elemento raiz
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("Trabajadores");
            doc.appendChild(rootElement);

            for (Trabajadorbbdd t : erroneos){
                // empleado
                Element empleado = doc.createElement("Trabajador");
                rootElement.appendChild(empleado);

                // atributo del elemento empleado
                Attr attr = doc.createAttribute("id");
                attr.setValue(String.valueOf(t.getIdTrabajador()));
                empleado.setAttributeNode(attr);

                // nombre
                Element nombre = doc.createElement("Nombre");
                nombre.appendChild(doc.createTextNode(t.getNombre()));
                empleado.appendChild(nombre);

                // 1º apellido
                Element primerApellido = doc.createElement("PrimerApellido");
                primerApellido.appendChild(doc.createTextNode(t.getApellido1()));
                empleado.appendChild(primerApellido);

                // 2º apellido
                Element segundoApellido = doc.createElement("SegundoApellido");
                segundoApellido.appendChild(doc.createTextNode(t.getApellido2()));
                empleado.appendChild(segundoApellido);

                // Categoria
                Element categoria = doc.createElement("Categoria");
                categoria.appendChild(doc.createTextNode(categoriasUtils.getNombreCategoria(t.getIdCategoria())));
                empleado.appendChild(categoria);

                // Empresa
                Element empresa = doc.createElement("Empresa");
                empresa.appendChild(doc.createTextNode(empresasUtils.getNombreEmpresa(t.getIdEmpresa())));
                empleado.appendChild(empresa);
            }


            // escribimos el contenido en un archivo .xml
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            StreamResult result = new StreamResult(new File("resources/Errores.xml"));
            //StreamResult result = new StreamResult(new File("Errores.xml"));

            // Si se quiere mostrar por la consola...
            // StreamResult result = new StreamResult(System.out);

            transformer.transform(source, result);

            System.out.println("Fichero Errores.xml creado!");

        } catch (ParserConfigurationException | TransformerException pce) {
            pce.printStackTrace();
        }

    }

    public void crearErroresCCCXML(ArrayList<Trabajadorbbdd> erroneos){

        try {

            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            // elemento raiz
            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement("Cuentas");
            doc.appendChild(rootElement);

            for (Trabajadorbbdd t : erroneos){
                // empleado
                Element empleado = doc.createElement("Cuenta");
                rootElement.appendChild(empleado);

                // atributo del elemento empleado
                Attr attr = doc.createAttribute("id");
                attr.setValue(String.valueOf(t.getIdTrabajador()));
                empleado.setAttributeNode(attr);

                // nombre
                Element nombre = doc.createElement("Nombre");
                nombre.appendChild(doc.createTextNode(t.getNombre()));
                empleado.appendChild(nombre);

                // 1º apellido
                Element primerApellido = doc.createElement("PrimerApellido");
                primerApellido.appendChild(doc.createTextNode(t.getApellido1()));
                empleado.appendChild(primerApellido);

                // 2º apellido
                Element segundoApellido = doc.createElement("SegundoApellido");
                segundoApellido.appendChild(doc.createTextNode(t.getApellido2()));
                empleado.appendChild(segundoApellido);

                // Empresa
                Element empresa = doc.createElement("Empresa");
                empresa.appendChild(doc.createTextNode(empresasUtils.getNombreEmpresa(t.getIdEmpresa())));
                empleado.appendChild(empresa);

                // CodigoCuentaErroneo
                Element codigoCuentaErroneo = doc.createElement("CodigoCuentaErroneo");
                codigoCuentaErroneo.appendChild(doc.createTextNode(t.getCodigoCuenta()));
                empleado.appendChild(codigoCuentaErroneo);

                // IBAN
                Element ibanCorrecto = doc.createElement("IBANCorrecto");
                ibanCorrecto.appendChild(doc.createTextNode(t.getIban()));
                empleado.appendChild(ibanCorrecto);
            }


            // escribimos el contenido en un archivo .xml
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            StreamResult result = new StreamResult(new File("resources/erroresCCC.xml"));
            //StreamResult result = new StreamResult(new File("Errores.xml"));

            // Si se quiere mostrar por la consola...
            // StreamResult result = new StreamResult(System.out);

            transformer.transform(source, result);

            System.out.println("Fichero erroresCCC.xml creado!");

        } catch (ParserConfigurationException | TransformerException pce) {
            pce.printStackTrace();
        }

    }


}
