import modelo.*;
import org.hibernate.*;
import org.hibernate.query.Query;
import util.HibernateUtil;

import javax.persistence.metamodel.EntityType;
import java.io.File;
import java.util.*;

public class Main {

    public static void main(final String[] args) throws Exception {

        /**
         * Acceso a hoja Excel
         */
        ExcelUtils excelUtils = new ExcelUtils();
        File excelFile = new File("resources/SistemasInformacionII.xlsx");

        /**
         * Estructura de Categorias con salario base y complementos
         */
        HashMap<String, ExcelUtils.WrapperCategoria> mapCategorias = excelUtils.cargarCategorias(excelFile);
        CategoriasUtils catUtils = new CategoriasUtils(mapCategorias);
        excelUtils.setCatUtils(catUtils);

        ArrayList<Categorias> categorias = catUtils.getCatList();
/*
        System.out.println("\nCATEGORIAS");
        for (Categorias c : categorias){
            System.out.println(c.toString());
        }
*/
        /**
         * LECTURA de datos de la hoja 1 - trabajadores
         */
        TrabajadorUtils tUtils = excelUtils.readExcelFile(excelFile);
        ArrayList<Trabajadorbbdd> trabajadores = tUtils.getTrabList();
        ArrayList<Empresas> empresas = tUtils.getEmpresas();
        /***************************************************************/
/*
        for(Trabajadorbbdd t : trabajadores){
            System.out.println(t.toString());
        }
*/
        /**
         *
         * GENERACIÓN DE ERRORES
         *
         */
        // ****************************** DNIS **************************************** //
        ArrayList<Trabajadorbbdd> erroresDni = excelUtils.comprobarDnis(trabajadores);
        excelUtils.crearErroresDniXML(erroresDni);

        /******************************************************************************/

        // ********************************* CCC e IBAN ******************************* //
        ArrayList<Trabajadorbbdd> erroresCCC = excelUtils.comprobarCCC(trabajadores);
        excelUtils.crearErroresCCCXML(erroresCCC);

        // ****************************** CORREO ************************************** //
        excelUtils.crearCorreo(trabajadores);

        /******************************************************************************/


        /**
         *
         * ESTRUCTURAS - HOJA 2
         *
         */
        // - Estructura TRABAJADOR con keys cuota "general", "desempleo", "formacion" y values en double
        HashMap<String, Double> mapTrabajador = (HashMap<String, Double>) excelUtils.cargarHoja2(excelFile, "trabajador");
        // System.out.println("Estructura trabajador: " + mapTrabajador);

        // - Estructura EMPRESARIO con keys "contingencias", "fogasa", "desempleo", "formacion", "accidentes" y values en double
        HashMap<String, Double> mapEmpresario = (HashMap<String, Double>) excelUtils.cargarHoja2(excelFile, "empresario");
        //System.out.println("Estructura empresario: " + mapEmpresario);

        // - Estructura trienios(key) - importe bruto(value)
        HashMap<Integer, Integer> mapTrienios = (HashMap<Integer, Integer>) excelUtils.cargarHoja2(excelFile, "trienios");
        //System.out.println("Estructura trienios: " + mapTrienios);
/*
        for (Integer name: mapTrienios.keySet()){
            String key = name.toString();
            Integer value = mapTrienios.get(name);
            System.out.println(key + ": " + value);
        }
*/

        // - Estructura brutos anuales(key) - retenciones(value)
        HashMap<Integer, Double> mapRetenciones = (HashMap<Integer, Double>) excelUtils.cargarHoja2(excelFile, "retenciones");
        //System.out.println("Estructura retenciones: " + mapRetenciones);

        // CALCULO DE NOMINAS
        tUtils.setTrabList(trabajadores);
        HacerNomina handleNominas = new HacerNomina( tUtils, catUtils, mapTrabajador, mapEmpresario, mapTrienios, mapRetenciones);

        handleNominas.calcularNomina();

        ArrayList<Nomina> nominas = handleNominas.getNominas();


            /*System.out.println("Nominas size: "+nominas.size());
            for(Nomina n : nominas){
                System.out.println(n.toString());
            }
*/
        GenerarPDF g = new GenerarPDF(tUtils, nominas, handleNominas.anio_nomina, handleNominas.mes_nomina, handleNominas.ProrrateoTrabajadores());


        /**
         * Acceso a la base de datos
         */
        /*final Session session = HibernateUtil.getSession();
        try {
            System.out.println("querying all the managed entities...");
            final Metamodel metamodel = session.getSessionFactory().getMetamodel();
            for (EntityType<?> entityType : metamodel.getEntities()) {
                final String entityName = entityType.getName();
                final Query query = session.createQuery("from " + entityName);
                System.out.println("executing: " + query.getQueryString());
                for (Object o : query.list()) {
                    System.out.println("  " + o);
                }
            }
            // ***************************************************************************

            // METEMOS EMPRESAS
            BBDDEmpresa bbddEmpresa = new BBDDEmpresa();

            for (Empresas e: empresas) {

                if(bbddEmpresa.existeEnBBDDEmpresa(e.getCif())){
                    bbddEmpresa.updateEmpresa(e.getIdEmpresa(),e.getNombre(),e.getCif());
                }else{
                    bbddEmpresa.addEmpresa(e.getNombre(),e.getCif());
                }

            }

            // METEMOS CATEGORIAS

            BBDDCategoria bbddCategoria = new BBDDCategoria();

            for(Categorias c : categorias){

                if(bbddCategoria.existeEnBBDDCategoria(c.getNombreCategoria())){
                    bbddCategoria.updateCategoria(c.getIdCategoria(),c.getNombreCategoria(),c.getSalarioBaseCategoria(),c.getComplementoCategoria());
                }else{
                    bbddCategoria.addCategoria(c.getNombreCategoria(),c.getSalarioBaseCategoria(),c.getComplementoCategoria());
                }

            }

            // METEMOS TRABAJADORES

            BBDDTrabajador bbddTrabajador = new BBDDTrabajador();

            ArrayList<Trabajadorbbdd> trabajadores_definitivos = new ArrayList<Trabajadorbbdd>();

            for (Trabajadorbbdd t: trabajadores) {
                if(!t.getNifnie().equals("")) {
                    int id = bbddTrabajador.existeEnBBDDTrabajador(t.getNombre(), t.getNifnie(), t.getFechaAlta().toString());
                    if (id != -1) {
                        bbddTrabajador.updateTrabajador(id, t.getIdCategoria(), t.getIdEmpresa(), t.getNombre(), t.getApellido1(), t.getApellido2(), t.getNifnie(), t.getEmail(), t.getFechaAlta(), t.getCodigoCuenta(), t.getIban());
                    } else {
                        bbddTrabajador.addTrabajador(t.getIdCategoria(), t.getIdEmpresa(), t.getNombre(), t.getApellido1(), t.getApellido2(), t.getNifnie(), t.getEmail(), t.getFechaAlta(), t.getCodigoCuenta(), t.getIban());

                    }
                }
            }

            // obtenemos los trabajadores, una vez filtrados los duplicados, existentes, etc.
            trabajadores_definitivos = (ArrayList<Trabajadorbbdd>) bbddTrabajador.listaTrabajador();

            *//*
            System.out.println("Trabajadores definitivos:");
            for(Trabajadorbbdd t : trabajadores_definitivos){
                System.out.println(t.toString());
            }
            */



            // ************************************************************************************ //

            // METEMOS NOMINAS
/*
            BBDDNomina bbddNomina = new BBDDNomina();

            for(Nomina n : nominas){

                if (bbddNomina.existeEnBBDDNomina(n.getMes(),n.getAnio(),n.getIdTrabajador(),n.getBrutoNomina(),n.getLiquidoNomina())){
                    bbddNomina.updateNomina(n);
                }else{
                    bbddNomina.addNomina(n);
                    //System.out.println("Id trabajador creada: "+n.getIdTrabajador());
                }
            }
        } finally {
            session.close();
        }*/
    }
}