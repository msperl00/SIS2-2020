
package sis2.pkg2020.modelo.enums;

/**
 *
 * @author Marco Speranza López
 */
public enum TipoColumnasHoja2 {
    
    CATEGORIA,SALARIOBASE,COMPLEMENTOS
}
