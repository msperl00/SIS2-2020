
package sis2.pkg2020.modelo.enums;

/**
 * Enum de la hoja 3 -> Bruto anual y retenciones.
 * @author Marco Speranza Lopez
 */
public enum TipoColumnasHoja3 {
    BRUTOANUAL, RETENCIONES
}
